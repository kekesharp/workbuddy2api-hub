"""Runtime settings for the gateway: panel password and API key override.

Everything lives in `accounts/settings.json` so a change made from the web
panel survives a restart without editing the launcher .bat files. The panel
password is never stored in clear text - only a PBKDF2-SHA256 digest.

Only the Python standard library is required.
"""

import fnmatch
import hashlib
import hmac
import json
import os
import random
import re
import secrets
import threading
import time

DEFAULT_PANEL_PASSWORD = "admin"
PBKDF2_ROUNDS = 120_000
SESSION_TTL = 7 * 24 * 3600
# How often the gateway pulls fresh prices, in minutes; keep in step with
# wb_pricing.DEFAULT_REFRESH_MINUTES.
DEFAULT_PRICING_REFRESH_MINUTES = 5.0
# The setting used to be counted in hours and stored under this key. It is read
# once on upgrade (x60) and rewritten under the new key, so 6 hours can never
# come back as 6 minutes.
LEGACY_PRICING_REFRESH_HOURS_KEY = "pricing_refresh_hours"
PRICING_REFRESH_MINUTES_KEY = "pricing_refresh_minutes"
# A month, the old cap converted: 720 hours = 43200 minutes.
MAX_PRICING_REFRESH_MINUTES = 24 * 30 * 60
# How stale an account's credit balance may get before the background
# refresher updates it, in hours. Only the sign-in / daily-activity tasks used
# to refresh balances, so a dispatch decision could rest on a balance days old.
# 12 hours is deliberately slack: the preference is measured in days, so half a
# day of drift moves an account by at most half a day inside a 7-day window,
# and the wider TTL keeps the refresher from spending upstream billing calls it
# does not need.
DEFAULT_CREDITS_REFRESH_HOURS = 12.0
MAX_CREDITS_REFRESH_HOURS = 24 * 30
CREDITS_REFRESH_HOURS_KEY = "credits_refresh_hours"
# Panel window height cap, in pixels: a dashboard window (section) taller than
# this scrolls internally with its title row pinned, instead of stretching the
# whole page. 0 turns the cap off. The default sits just above the log
# terminal's own 620px so the terminal stays untouched until the user asks for
# something smaller.
SECTION_MAX_HEIGHT_KEY = "section_max_height"
DEFAULT_SECTION_MAX_HEIGHT = 640
MAX_SECTION_MAX_HEIGHT = 4000
# How many app-layer backups a successful update keeps under <app>/updates.
# Rollback works off those backups, so 0 means "no rollback at all"; 1 is the
# default because it is enough to undo one step and each backup is a few MB.
# Capped at 3: the app layer is ~5 MB per copy and the container's rootfs is
# small, so an unbounded value is a foot-gun rather than a feature.
KEEP_BACKUPS_KEY = "keep_backups"
DEFAULT_KEEP_BACKUPS = 1
MAX_KEEP_BACKUPS = 3
# Whether a model name may inherit its price from a suffix-stripped base
# (deepseek-r1-0528-lkeap → deepseek-r1-0528). Missing key reads as on.
PRICING_VARIANT_INHERIT_KEY = "pricing_variant_inherit"
# Master switch for the whole OpenRouter price-estimation feature. Missing key
# reads as on: an install that predates the setting behaves exactly as it did,
# and only an explicit false turns the feature off.
PRICING_ENABLED_KEY = "pricing_enabled"
# Whether the panel's account section is collapsed. Missing, or anything that is
# not the boolean true, reads as expanded: a fresh install and a value a hand
# edit or an older client left behind both keep the default view, and only an
# explicit true hides the accounts.
ACCOUNTS_COLLAPSED_KEY = "accounts_collapsed"
# Whether the panel's per-API-key table folds away its `(切换前)` row - the
# legacy tail of requests logged before the key field existed. Same
# normalisation as the disclosure above: only an explicit boolean true hides
# the row, so a hand edit or an older client cannot drop it by accident.
KEY_BEFORE_HIDDEN_KEY = "key_before_hidden"
# Which top-bar pages the panel keeps out of the nav, as a list of page keys
# ("tasks", "logs", ...). Deliberately not validated against a page registry:
# the pages live in dashboard.html, and the panel ignores a key it does not
# know, so adding or renaming a page upstream never needs a change here. A
# missing key, a hand-written string or any other malformed value reads as
# "nothing hidden" - the fail-safe direction for a display preference.
HIDDEN_PAGES_KEY = "hidden_pages"
# Page keys are the same lowercase identifiers switchMainTab() switches on.
PAGE_KEY_RE = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")
# The one page that is never hidden, whatever the request or the file says: it
# is where this switch itself lives, so hiding it would leave the panel with no
# way back. Dropped during normalisation, so the stored file cannot hold it
# either and no client of this API can lock itself out.
PAGE_KEEP_VISIBLE = "settings"
# Bound on the stored list. The panel sends at most one entry per page, so this
# only limits what a hand edit can put in the file.
MAX_HIDDEN_PAGES = 32
# Whether the panel's account sections get a main tab of their own instead of
# sharing the gateway page. Missing, or anything that is not the boolean true,
# reads as off: an install that predates the setting keeps the single
# "网关与账号" tab it has always had, and only an explicit true splits it into
# 网关 + 账号. Same `is True` normalisation as the two switches above, so a
# hand-edited "false", a 1 or an object cannot split the nav by accident.
ACCOUNTS_SEPARATE_TAB_KEY = "accounts_separate_tab"

# Instance-wide default UI language. The dashboard can override this per
# browser with localStorage; this key is the fallback when no override exists.
UI_LANGUAGE_KEY = "ui_language"
UI_LANGUAGE_DEFAULT = "zh"
UI_LANGUAGE_VALUES = ("zh", "zh-Hant", "en")

# Whether the gateway checks GitHub for a newer release once a day. Missing key
# reads as off - the opposite of the switches above - because turning it on
# makes the gateway send a request on its own schedule.
UPDATE_CHECK_ENABLED_KEY = "update_check_enabled"
UPDATE_CHECK_PROXY_SLOT_KEY = "update_check_proxy_slot"
# The last-check bookkeeping for that daily check. One small object, never a
# general update-state store: see update_check_state().
UPDATE_CHECK_STATE_KEY = "update_check"
# How many startup-check timestamps that object keeps. Enough to count an hour
# of restarts, and a hard cap so the file cannot grow with uptime.
STARTUP_CHECK_STAMPS_KEPT = 12

# 剩余用量优先调度：把「估计剩余快耗尽」的 (账号, 模型) 先交出去（剩余越少
# 权重越高）。缺失键读作关：估算本身是从撞线样本反推的，优先它是一次刻意的
# 取舍（那些组合会明显多接流量），所以老安装保持原样的纯轮询。
REMAINING_PRIORITY_ENABLED_KEY = "remaining_priority_enabled"

# 出口级瞬时失败退避（issue #271）：传输类失败与 502/503/504 不再进账号级熔断
# 计数，改记在出口上、退避降到秒级（见 wb_egress）。缺失键读作关：它改变的是
# 派发路径上的失败归账与退避尺度，老安装保持原样（传输错误仍喂账号熔断）。
EGRESS_BACKOFF_ENABLED_KEY = "egress_backoff_enabled"

# 跨出口回退（国际版 → 国内版）：国际版出口把某个模型限流 / 当日额度用满 /
# 整池冷却时，允许拿同名的国内版出口再试一次。缺失键读作关 —— 两个出口是两套
# 上游、两套额度、两套积分口径，混用会让「这个 Key 只花国际额度」的部署失去
# 保证，所以老安装保持出口严格隔离（realm 一次定死，账号池按 realm 过滤）。
# 打开后方向仍是单向的：只有 intl → cn，永远不会把请求从国内版打到国际版。
REALM_FALLBACK_ENABLED_KEY = "realm_fallback_enabled"

# 账号级并发上限：同一个上游账号同时最多跑几个 chat 请求。缺失键读作 0（不限），
# 老安装的派发行为与上游一字不差。
#
# 为什么需要它：上游按「账号 + 分钟」计 token（TPM），而一个大上下文会话单请求
# 就带十几万 token。两个会话同时落在一个账号上，一分钟内轻松过百万 token，上游
# 直接回 429；网关随即把该账号停放 60 秒并换号，新账号没有这段对话的前缀缓存，
# 缓存命中率从 99% 掉到 0、TTFT 从 1.5s 涨到 5-6s。也就是说「并发越高」反而让
# 每个请求更慢。设成 1 时两个会话自然分到两个账号，各走各的缓存。
ACCOUNT_MAX_CONCURRENT_KEY = "account_max_concurrent"
#: 上限值域：0 = 不限；1..10 是「每账号同时几个」。10 只是防手滑的上界。
ACCOUNT_MAX_CONCURRENT_MAX = 10


def account_max_concurrent(accounts_dir):
    """How many chat requests one upstream account may run at once.

    0 (the default) means unlimited: dispatch behaves exactly as upstream does.
    Anything unreadable falls back to 0 rather than to a limit, so a hand-edited
    settings.json can never silently throttle a working install.
    """
    value = load(accounts_dir).get(ACCOUNT_MAX_CONCURRENT_KEY)
    if isinstance(value, bool) or not isinstance(value, int):
        return 0
    if value < 0 or value > ACCOUNT_MAX_CONCURRENT_MAX:
        return 0
    return value


def set_account_max_concurrent(accounts_dir, value):
    """Persist the per-account concurrency cap. Returns the stored whole number."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("account_max_concurrent must be a whole number")
    if value < 0:
        raise ValueError("account_max_concurrent cannot be less than 0")
    if value > ACCOUNT_MAX_CONCURRENT_MAX:
        raise ValueError("account_max_concurrent cannot be more than %d"
                         % ACCOUNT_MAX_CONCURRENT_MAX)
    with _lock:
        data = load(accounts_dir)
        data[ACCOUNT_MAX_CONCURRENT_KEY] = value
        save(accounts_dir, data)
    return value

# 更稳的会话粘滞键：把「首条 assistant 回复 + 它后面那条 user」也算进会话键。
#
# 为什么需要：会话键原本只用【system + 首条 user】，两个开场白相同的会话会算出
# 同一个键、共享同一个绑定槽，于是每轮互相覆盖、轮流换账号，缓存每轮归零
# （见 affinity_route）。把第 2 轮才出现的内容算进去之后，两个会话从第 2 轮起
# 各走各的账号；前缀真的完全相同的会话仍会共用账号——那本来就是最优的缓存共享。
#
# 默认关：改的是派发路径上的会话识别，老安装必须保持原逻辑。关着时
# affinity_route 与上游一字不差，可随时回退。
AFFINITY_STABLE_KEY_ENABLED_KEY = "affinity_stable_key_enabled"


def affinity_stable_key_enabled(accounts_dir):
    """Whether the conversation key also covers the first assistant turn."""
    return load(accounts_dir).get(AFFINITY_STABLE_KEY_ENABLED_KEY) is True


def set_affinity_stable_key_enabled(accounts_dir, enabled):
    """Persist the stable-affinity-key switch. Returns the stored boolean.

    Strict on purpose: ``bool("false")`` is True, so a string that slipped in
    from a caller would silently turn the new key on. The HTTP layer already
    rejects non-booleans; this keeps every other caller honest too.
    """
    if not isinstance(enabled, bool):
        raise ValueError("affinity_stable_key_enabled must be true or false")
    with _lock:
        data = load(accounts_dir)
        data[AFFINITY_STABLE_KEY_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled

# 日志落库：把运行日志追加写进 usage/logs.sqlite3，重启后仍能回看，方便事后
# debug。缺失键读作关 —— 关着的时候日志只留在内存环形缓冲里，与上游一字不差；
# 只有显式 true 才建库、落盘。
LOG_DB_ENABLED_KEY = "log_db_enabled"
# 三条互相独立的保留上限，各自「留空 = 这一维不设限」：
#   * rows  —— 只留最新的 N 条（空 = 不限条数）
#   * days  —— 只留最近 N 天（空 = 不限天数；**默认 7 天**）
#   * bytes —— 库文件超过 N 字节就从最旧的删起，缩回 N 以内（空 = 不限大小）
# 天数给了 7 天默认值，是因为「无限增长的日志库」才是要防的那件事；条数与
# 字节数留空（不限），因为单独看任何一个都可能偏严或偏松，交给使用者按需填。
LOG_DB_MAX_ROWS_KEY = "log_db_max_rows"
LOG_DB_MAX_DAYS_KEY = "log_db_max_days"
LOG_DB_MAX_BYTES_KEY = "log_db_max_bytes"
DEFAULT_LOG_DB_MAX_DAYS = 7
# 上限只用来挡手滑：手编 settings.json 写个天文数字不该把裁剪循环拖死，也不该
# 让面板显示一个溢出成科学计数法的值。都远大于任何真实部署会用的量级。
MAX_LOG_DB_MAX_ROWS = 100_000_000
MAX_LOG_DB_MAX_DAYS = 36500
MAX_LOG_DB_MAX_BYTES = 100 * 1024 ** 3

_lock = threading.RLock()


def settings_path(accounts_dir):
    return os.path.join(accounts_dir, "settings.json")


class PanelPasswordCryptoError(RuntimeError):
    """Raised when hashlib.pbkdf2_hmac is missing or fails due to interpreter environment issues."""
    pass


def check_pbkdf2_available():
    """Verify hashlib.pbkdf2_hmac is functional in this interpreter.

    Returns (ok: bool, reason: str).
    """
    if not hasattr(hashlib, "pbkdf2_hmac"):
        return False, "module 'hashlib' has no attribute 'pbkdf2_hmac'"
    try:
        hashlib.pbkdf2_hmac("sha256", b"smoke", b"salt", 1)
        return True, ""
    except Exception as exc:
        return False, str(exc)


def _digest(password, salt_hex, rounds=PBKDF2_ROUNDS):
    if not hasattr(hashlib, "pbkdf2_hmac"):
        raise PanelPasswordCryptoError(
            "当前 Python 解释器缺少 hashlib.pbkdf2_hmac 支持，无法进行密码哈希计算。"
            "若使用 Windows 便携版 Python，请检查系统安全策略（如 Smart App Control）是否拦截了 DLLs/_hashlib.pyd。"
        )
    try:
        salt_bytes = bytes.fromhex(salt_hex)
    except (ValueError, TypeError) as exc:
        raise ValueError(f"invalid password salt hex: {exc}") from exc
    try:
        return hashlib.pbkdf2_hmac(
            "sha256", password.encode("utf-8"), salt_bytes, rounds
        ).hex()
    except (AttributeError, ImportError, ModuleNotFoundError, NotImplementedError, RuntimeError, OSError) as exc:
        raise PanelPasswordCryptoError(
            f"当前 Python 解释器计算 hashlib.pbkdf2_hmac 失败: {exc}。"
            "若使用 Windows 便携版 Python，请检查系统安全策略（如 Smart App Control）是否拦截了 DLLs/_hashlib.pyd。"
        ) from exc


# settings.json 的解析结果按 (path, mtime, size) 缓存：请求热路径上它被读约 10
# 次（prompt_config×2 / api_keys×2 / limits_data×3 / auto_switch_product /
# upstream_config×2），单次 156~273µs，合计 1.6~2.7ms/请求。所有写入都走 save()
# 的 os.replace 原子替换，mtime/size 必变，所以面板改动仍然即时生效；save() 里
# 再主动失效一次，连 mtime 精度粗（FAT 只有 2s）的同尺寸改写也不会读到旧值。
# 调用方拿到的是顶层浅拷贝：与原实现「每次重新解析、返回值随便改」的语义一致
# （现网所有 setter 都只改顶层键再 save()，嵌套值按约定只读），改返回值也不会
# 弄脏缓存。
_load_cache = {"key": None, "value": {}}


def load(accounts_dir):
    """Return the persisted settings, or an empty dict on a fresh install.

    Cached on (path, mtime, size); the returned dict is a fresh top-level copy
    so callers keep the previous "mutate freely" semantics.
    """
    path = settings_path(accounts_dir)
    try:
        info = os.stat(path)
        key = (path, info.st_mtime, info.st_size)
    except OSError:
        key = (path, None, None)
    with _lock:
        if _load_cache["key"] == key:
            return dict(_load_cache["value"])
    data = {}
    try:
        with open(path, encoding="utf-8") as fh:
            parsed = json.load(fh)
        if isinstance(parsed, dict):
            data = parsed
    except FileNotFoundError:
        pass
    except Exception:
        pass
    with _lock:
        _load_cache.update({"key": key, "value": data})
    return dict(data)


def save(accounts_dir, data):
    """Atomic write so a crash cannot leave a half-written settings file."""
    with _lock:
        os.makedirs(accounts_dir, exist_ok=True)
        path = settings_path(accounts_dir)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        # 写完主动失效：不依赖文件系统 mtime 的精度（FAT 只有 2s），保证同尺寸
        # 改写的下一个 load() 一定重新读盘。
        _load_cache["key"] = None
        return path


def deep_merge(base, patch):
    """Recursively merge patch into base; unknown sibling keys survive.

    The panel form only submits the keys it manages. Replacing a whole group
    would silently drop hand-written or future keys, so nested objects merge
    key by key. Returns a new dict; the inputs are not mutated.
    """
    if not isinstance(base, dict) or not isinstance(patch, dict):
        return patch
    out = dict(base)
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def panel_password_is_default(accounts_dir):
    data = load(accounts_dir)
    if not data.get("panel_password_hash"):
        return True
    return data.get("panel_password_default") is True


def verify_panel_password(accounts_dir, password):
    """True when `password` opens the web panel."""
    password = password or ""
    data = load(accounts_dir)
    stored = data.get("panel_password_hash")
    if not stored:
        return password == DEFAULT_PANEL_PASSWORD
    if data.get("panel_password_default") is True:
        return password == DEFAULT_PANEL_PASSWORD
    salt = data.get("panel_password_salt")
    if not salt:
        return False
    rounds = int(data.get("panel_password_rounds") or PBKDF2_ROUNDS)
    try:
        given = _digest(password, salt, rounds)
    except PanelPasswordCryptoError:
        raise
    except ValueError:
        return False
    return hmac.compare_digest(given, stored)


def set_panel_password(accounts_dir, password):
    with _lock:
        data = load(accounts_dir)
        if password == DEFAULT_PANEL_PASSWORD:
            data.pop("panel_password_salt", None)
            data.pop("panel_password_rounds", None)
            data["panel_password_hash"] = ""
            data["panel_password_default"] = True
        else:
            salt = secrets.token_hex(16)
            data["panel_password_salt"] = salt
            data["panel_password_rounds"] = PBKDF2_ROUNDS
            data["panel_password_hash"] = _digest(password, salt)
            data["panel_password_default"] = False
        save(accounts_dir, data)


def api_key_override(accounts_dir):
    """Return (key, is_set). `is_set` means the panel manages the key."""
    data = load(accounts_dir)
    if not data.get("api_key_set"):
        return None, False
    return str(data.get("api_key") or ""), True


def set_api_key(accounts_dir, key):
    with _lock:
        data = load(accounts_dir)
        data["api_key"] = key or ""
        data["api_key_set"] = True
        save(accounts_dir, data)


def ensure_launcher_key(accounts_dir):
    """Return the persisted LAN key, creating one on first use.

    LAN mode must never ship a well-known default: the gateway spends the
    account's own upstream quota, so anyone on the same network could drain it.
    The value is generated once and stored so clients keep working across
    restarts. Returns (key, created) so the caller can tell the user whether
    this run minted a fresh credential.
    """
    with _lock:
        data = load(accounts_dir)
        existing = str(data.get("launcher_key") or "").strip()
        if existing:
            return existing, False
        key = "wb-" + secrets.token_urlsafe(24)
        data["launcher_key"] = key
        save(accounts_dir, data)
        return key, True


# --------------------------------------------------------------- API keys
# Each key can be bound to one upstream realm, so several clients can hit
# different exits at the same time instead of sharing the global switch.

REALMS = ("", "intl", "cn", "codearts")


def codearts_config(accounts_dir):
    """CodeArts 配置的薄包装，避免 wb_settings ↔ wb_codearts 的模块级循环。"""
    import wb_codearts
    return wb_codearts.load_config(accounts_dir)


def set_codearts_config(accounts_dir, patch):
    import wb_codearts
    return wb_codearts.save_config(accounts_dir, patch)


def codearts_configured(accounts_dir):
    import wb_codearts
    return wb_codearts.configured(accounts_dir)


def _clean_model_patterns(value):
    """Normalize one key's model allow-list into a list of lowercase patterns.

    The panel posts a list; a hand-edited settings.json tends to hold a
    comma-separated string, so both shapes are accepted. Matching is done with
    fnmatch, which makes an exact name (`gpt-6-astra`) and a wildcard
    (`deepseek/*`) behave the same way. An empty result means "no restriction",
    which is what every key written before this field existed reads back as -
    an upgrade therefore keeps behaving exactly as before.
    """
    if isinstance(value, str):
        raw = [part for part in re.split(r"[,;\n]", value)]
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        return []
    out = []
    for item in raw:
        pattern = str(item or "").strip().lower()
        if pattern and pattern not in out:
            out.append(pattern)
    return out


def key_allows_model(entry, model):
    """True when `entry` places no model restriction, or `model` matches it.

    A key with an empty list stays unrestricted, so nothing changes for
    installs that never touch this field. A restricted key that names no model
    is refused instead of waved through: nothing in the request says it is
    asking for something the key may use, and forwarding it only reaches the
    upstream carrying an empty model, spending an attempt on a call that cannot
    succeed.
    """
    patterns = _clean_model_patterns((entry or {}).get("models"))
    if not patterns:
        return True
    name = str(model or "").strip().lower()
    if not name:
        return False
    return any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)


#: One key can name at most this many accounts. The pool is smaller than this
#: in practice; the cap only stops a hand-edited file from growing the
#: per-request filter without bound.
KEY_ACCOUNTS_MAX = 200
#: Account ids are UUIDs (36 chars); the length cap leaves room for a future
#: shorter ref without accepting arbitrary text.
KEY_ACCOUNT_MAX_LEN = 128


def _clean_account_refs(value):
    """Normalize one key's account allow-list into a list of account ids.

    The panel posts a list; a hand-edited settings.json tends to hold a
    comma-separated string, so both shapes are accepted. Matching is exact
    (account uid), because a wildcard here would silently widen a restriction
    meant to pin traffic to named accounts. An empty result means "no
    restriction", which is what every key written before this field existed
    reads back as.
    """
    if isinstance(value, str):
        raw = [part for part in re.split(r"[,;\n]", value)]
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        return []
    out = []
    for item in raw:
        ref = str(item or "").strip()
        if not ref or len(ref.encode("utf-8")) > KEY_ACCOUNT_MAX_LEN:
            continue
        if ref not in out:
            out.append(ref)
        if len(out) >= KEY_ACCOUNTS_MAX:
            break
    return out


def key_allowed_accounts(entry):
    """The account ids a key may use, or None when it places no restriction.

    None (not an empty set) is what the scheduler treats as "every account",
    so an unrestricted key keeps the exact code path it had before.
    """
    refs = _clean_account_refs((entry or {}).get("accounts"))
    return set(refs) if refs else None


def key_allows_account(entry, uid):
    """True when `entry` places no account restriction, or names `uid`."""
    refs = _clean_account_refs((entry or {}).get("accounts"))
    if not refs:
        return True
    return str(uid or "").strip() in refs


def _clean_key_entry(entry):
    """Normalize one stored key entry; returns None when unusable.

    A deleted entry keeps its row even though its secret is gone: the id is
    what the usage log records, so dropping the row would make every past
    request of that key unattributable. Deletion is one-way - the secret is
    never stored again and the entry can only ever be read, not re-enabled.
    """
    if not isinstance(entry, dict):
        return None
    key = str(entry.get("key") or "").strip()
    deleted_at = str(entry.get("deleted_at") or "").strip()
    if not key and not deleted_at:
        return None
    realm = str(entry.get("realm") or "").strip().lower()
    if realm not in REALMS:
        realm = ""
    try:
        concurrency = int(entry.get("concurrency_limit") or entry.get("max_concurrency") or 0)
    except (TypeError, ValueError):
        concurrency = 0
    concurrency = max(0, concurrency)
    return {
        "id": str(entry.get("id") or secrets.token_hex(6)),
        "name": str(entry.get("name") or "").strip() or "未命名",
        "key": key,
        "realm": realm,
        "models": _clean_model_patterns(entry.get("models")),
        "accounts": _clean_account_refs(entry.get("accounts")),
        "concurrency_limit": concurrency,
        "enabled": False if deleted_at else entry.get("enabled", True) is not False,
        "created_at": entry.get("created_at") or time.strftime("%Y/%m/%d %H:%M"),
        "deleted_at": deleted_at,
    }


def _unique_key_id(candidate, used):
    """Return `candidate`, or a variant that is not already in `used`.

    Ids used to be minted from the row's index in the submitted list, so a
    settings file written by an older build can hold two rows carrying the same
    id. `/settings/reveal` then answered with whichever row came first, which
    made the copy button on the other row hand out a different key. Later
    duplicates get a numeric suffix: the suffix is deterministic, so the id a
    `/settings` read just returned still resolves on the follow-up reveal.
    """
    candidate = str(candidate or "").strip()
    if candidate and candidate not in used:
        return candidate
    if candidate:
        suffix = 2
        while True:
            alt = "%s-%d" % (candidate, suffix)
            if alt not in used:
                return alt
            suffix += 1
    while True:
        alt = secrets.token_hex(6)
        if alt not in used:
            return alt


def api_keys(accounts_dir, include_deleted=False):
    """Every configured key, newest shape first.

    A settings file written by an older build only has the single
    `api_key`/`api_key_set` pair; that is surfaced as one unbound entry so
    upgrades keep working without a migration step. Ids are made unique here
    as well as on write, so a file that already holds a duplicate (and no
    longer has to be saved before it behaves) reads back as distinct rows.

    Deleted entries are hidden by default: they are gone as credentials, and
    match_api_key must never see them. Their rows stay on disk (and come back
    with include_deleted) because the usage log names a key by id, and an id
    with no name is not a table anyone can read.
    """
    data = load(accounts_dir)
    stored = data.get("api_keys")
    if isinstance(stored, list):
        out = []
        seen = set()
        seen_ids = set()
        for raw in stored:
            entry = _clean_key_entry(raw)
            if entry is None:
                continue
            # Deduplicate on the secret, and only when there is one: every
            # deleted entry has an empty key, and those are distinct rows.
            if entry["key"]:
                if entry["key"] in seen:
                    continue
                seen.add(entry["key"])
            entry["id"] = _unique_key_id(entry["id"], seen_ids)
            seen_ids.add(entry["id"])
            out.append(entry)
        if not include_deleted:
            out = [e for e in out if not e.get("deleted_at")]
        return out

    if data.get("api_key_set"):
        legacy = str(data.get("api_key") or "").strip()
        if legacy:
            return [{
                "id": "legacy",
                "name": "默认（跟随面板切换）",
                "key": legacy,
                "realm": "",
                "models": [],
                "enabled": True,
                "created_at": "",
                "deleted_at": "",
            }]
    return []


def _retired_key_entry(old):
    """The soft-deleted form of a stored key: name and dates kept, secret gone."""
    return {
        "id": old["id"],
        "name": old["name"],
        "key": "",
        "realm": old.get("realm") or "",
        "models": old.get("models") or [],
        "enabled": False,
        "created_at": old.get("created_at") or "",
        "deleted_at": old.get("deleted_at") or time.strftime("%Y/%m/%d %H:%M"),
    }


def set_api_keys(accounts_dir, keys, delete_ids=None):
    """Save the key list. Returns the saved (live) list.

    Removal is a soft delete: the usage log attributes spend by id, so losing
    an id would dump a key's whole history into "(未知 key)", and the secret is
    wiped at the same moment so a deleted key can never authenticate again.

    Two modes decide which stored keys get soft-deleted:

    - `delete_ids is None`: replace semantics. Any stored key absent from
      `keys` is retired. This is what an older panel relies on - it deletes a
      row by leaving it out of the submission - so it stays the default.
    - `delete_ids` is a list: upsert semantics. Only those ids are retired; a
      stored key the submission does not mention is left untouched. The panel
      uses this because its submission is whatever its in-memory rows happen
      to be, and a list that is stale or incomplete (a second browser tab, a
      save that raced the post-save reload, a reload that failed) must not
      retire a key the user never removed.
    """
    with _lock:
        previous = api_keys(accounts_dir, include_deleted=True)
        upsert = delete_ids is not None
        drop = {str(entry_id) for entry_id in (delete_ids or [])}
        # Upsert mode: a stored live secret, so a submitted row that lost its id
        # (a stale panel resubmitting a key it already saved) can adopt the
        # stored id and update that key in place instead of minting a new one
        # and splitting its usage history in two.
        live_secret_id = {}
        if upsert:
            for old in previous:
                if old["key"] and not old.get("deleted_at"):
                    live_secret_id.setdefault(old["key"], old["id"])
        cleaned = []
        seen = set()
        seen_ids = set()
        for raw in keys or []:
            raw_id = str((raw or {}).get("id") or "").strip() if isinstance(raw, dict) else ""
            entry = _clean_key_entry(raw)
            if entry is None:
                continue
            if entry["key"]:
                if entry["key"] in seen:
                    continue
                seen.add(entry["key"])
            if upsert and entry["key"] and raw_id not in live_secret_id.values():
                entry["id"] = live_secret_id.get(entry["key"], entry["id"])
            entry["id"] = _unique_key_id(entry["id"], seen_ids)
            seen_ids.add(entry["id"])
            cleaned.append(entry)
        for old in previous:
            if old["id"] in seen_ids:
                continue
            seen_ids.add(old["id"])
            # Upsert mode keeps a stored key the submission never mentioned.
            # An already-deleted row is kept too: it is read-only history.
            if upsert and old["id"] not in drop:
                # A submitted row may already carry this exact secret (the
                # stale submission re-sent it under a fresh id). Two live rows
                # with one secret is the duplicate this mode exists to avoid,
                # so the stale stored copy is retired instead.
                if old["key"] and old["key"] in seen:
                    cleaned.append(_retired_key_entry(old))
                    continue
                if old["key"]:
                    seen.add(old["key"])
                cleaned.append(old)
                continue
            cleaned.append(_retired_key_entry(old))
        data = load(accounts_dir)
        data["api_keys"] = cleaned
        # The single-key fields are now derived; drop them so there is one
        # source of truth and the list survives a restart.
        data.pop("api_key", None)
        data.pop("api_key_set", None)
        save(accounts_dir, data)
        return [e for e in cleaned if not e.get("deleted_at")]


def match_api_key(accounts_dir, supplied, extra_keys=()):
    """Find which configured key a request presented, if any.

    Returns a copy of the entry (with a `source` field) so the caller can read
    the bound realm, or None when nothing matches.
    """
    supplied = (supplied or "").strip()
    if not supplied:
        return None
    for entry in api_keys(accounts_dir):
        # A deleted entry is already stored with enabled=False; the explicit
        # check keeps a hand-edited settings file from reviving one.
        if entry["enabled"] and not entry.get("deleted_at") \
                and hmac.compare_digest(supplied, entry["key"]):
            out = dict(entry)
            out["source"] = "panel"
            return out
    for candidate in extra_keys:
        candidate = (candidate or "").strip()
        if candidate and hmac.compare_digest(supplied, candidate):
            return {
                "id": "launcher",
                "name": "启动参数",
                "key": candidate,
                "realm": "",
                "models": [],
                "enabled": True,
                "source": "launcher",
            }
    return None


def auth_disabled(accounts_dir):
    """True when the operator switched API-key checking off entirely."""
    return load(accounts_dir).get("auth_disabled") is True


def set_auth_disabled(accounts_dir, disabled):
    with _lock:
        data = load(accounts_dir)
        data["auth_disabled"] = bool(disabled)
        save(accounts_dir, data)


# ------------------------------------------------------------------ limits
# The four guards share one shape: a global default that covers both realms,
# plus an optional per-realm override. An override left empty inherits the
# global value, so an install that never touches it behaves exactly as before,
# and one that does only ever has to reason about a single number per guard.
LIMIT_KEYS = ("reserve_credits", "daily_token_limit",
              "daily_credit_limit", "model_daily_token_limit",
              "expiring_window_days")
LIMIT_REALMS = ("intl", "cn")
LIMIT_SCOPES = ("global",) + LIMIT_REALMS
LIMITS_KEY = "limits"

# Guards whose global default is not "off". Every key still reads 0 as off;
# only the expiring-credits window ships enabled, because 0 would make the
# preference a silent no-op until someone turned it on by hand.
LIMIT_DEFAULTS = {"expiring_window_days": 7}


def _default_global(key):
    """The global value an install reads before it ever saves one."""
    try:
        return max(0, int(LIMIT_DEFAULTS.get(key, 0)))
    except (TypeError, ValueError):
        return 0


def _empty_limit_entry(key=None):
    """One guard: a global default plus a slot per realm (None = inherit)."""
    return {"global": _default_global(key), "intl": None, "cn": None}


def _coerce_global(value):
    """A global threshold. Junk and negatives collapse to 0 (off), which is
    also what every install predating the setting reads as."""
    try:
        number = int(value or 0)
    except (TypeError, ValueError):
        number = 0
    return max(0, number)


def _coerce_override(value):
    """A per-realm override. None (or a blank form field) means "inherit the
    global default", kept distinct from an explicit 0 ("off for this realm")."""
    if value is None or value == "":
        return None
    try:
        number = int(value)
    except (TypeError, ValueError):
        return None
    return max(0, number)


def _fold_legacy_limits(data):
    """Move the four flat top-level guards into `limits`.

    Returns (changed, limits). The old keys are dropped as they are folded in,
    so a later rollback cannot resurrect a stale limit from beside the grouped
    copy.
    """
    limits = {}
    changed = False
    for key in LIMIT_KEYS:
        entry = _empty_limit_entry(key)
        if key in data:
            entry["global"] = _coerce_global(data.pop(key))
            changed = True
        limits[key] = entry
    return changed, limits


def _normalize_limits(raw):
    """A copy of the stored map with every key and scope filled in, so a
    partial or hand-edited settings.json still reads as a complete shape."""
    limits = {}
    for key in LIMIT_KEYS:
        entry = raw.get(key)
        if not isinstance(entry, dict):
            entry = {}
        global_raw = entry.get("global")
        # A missing global falls back to that guard's own default (0 for every
        # guard but the expiring window); an explicit 0 is a real "off" and is
        # kept as one, so a saved "off" never silently comes back on.
        global_value = (_default_global(key) if global_raw is None
                        else _coerce_global(global_raw))
        limits[key] = {
            "global": global_value,
            "intl": _coerce_override(entry.get("intl")),
            "cn": _coerce_override(entry.get("cn")),
        }
    return limits


def limits_data(accounts_dir):
    """The grouped limits map, migrating a flat pre-grouping file on first read.

    Reading is what upgrades: the first look at an old settings.json folds the
    four flat keys into `limits` and rewrites the file, so the rest of the
    gateway only ever sees one shape.
    """
    with _lock:
        data = load(accounts_dir)
        raw = data.get(LIMITS_KEY)
        if isinstance(raw, dict):
            return _normalize_limits(raw)
        changed, limits = _fold_legacy_limits(data)
        if changed:
            data[LIMITS_KEY] = limits
            try:
                save(accounts_dir, data)
            except Exception:
                # A read-only accounts dir must not take the panel down; the
                # folded values are still returned and the next read retries.
                pass
        return limits


def limits_snapshot(accounts_dir):
    """The panel's view of every guard, keyed by limit then by scope."""
    return limits_data(accounts_dir)


def limit_value(accounts_dir, key, realm=None):
    """One guard's effective value for a realm.

    realm None (or "") returns the global default; an intl/cn override wins
    when it is set. An unknown key reads as 0 (off), so a typo cannot wedge
    the request path.
    """
    entry = limits_data(accounts_dir).get(key) or _empty_limit_entry()
    if realm in LIMIT_REALMS:
        override = entry.get(realm)
        if override is not None:
            return override
    return entry.get("global") or 0


def limit_values_many(accounts_dir, keys):
    """Several guards resolved for every realm, off one settings read.

    limit_values() per key re-reads the file (cached by mtime/size, so a stat)
    and re-normalizes the whole grouped map every call; the daily guards all
    want the same map on the request path, so they share one read here. One
    implementation only: limit_values() is this with a single key.
    """
    grouped = limits_data(accounts_dir)
    out = {}
    for key in keys:
        entry = grouped.get(key) or _empty_limit_entry()
        global_value = entry.get("global") or 0
        values = {"global": global_value}
        for realm in LIMIT_REALMS:
            override = entry.get(realm)
            values[realm] = global_value if override is None else override
        out[key] = values
    return out


def limit_values(accounts_dir, key):
    """One guard resolved for every realm plus the global it inherits.

    {"global": g, "intl": ..., "cn": ...}. The intl/cn entries already carry
    the global value when no override is set, so the pool can hand each
    account its own realm without a second settings lookup.
    """
    return limit_values_many(accounts_dir, (key,))[key]


def set_limit(accounts_dir, key, scope, value):
    """Persist one guard at one scope. Returns the stored entry.

    scope is "global", "intl" or "cn"; a None/blank value clears an intl/cn
    override back to "inherit", while the global slot always stores a number.
    """
    if key not in LIMIT_KEYS:
        raise ValueError("unknown limit: %s" % key)
    if scope not in LIMIT_SCOPES:
        raise ValueError("unknown scope: %s" % scope)
    with _lock:
        data = load(accounts_dir)
        raw = data.get(LIMITS_KEY)
        if isinstance(raw, dict):
            limits = _normalize_limits(raw)
        else:
            _changed, limits = _fold_legacy_limits(data)
        entry = limits[key]
        if scope == "global":
            entry["global"] = _coerce_global(value)
        else:
            entry[scope] = _coerce_override(value)
        data[LIMITS_KEY] = limits
        save(accounts_dir, data)
    return entry


def reserve_credits(accounts_dir, realm=None):
    """Global low-credit guard: an account at or below this balance stays idle.

    Zero disables the guard, which keeps installs that predate the setting
    behaving exactly as before.
    """
    return limit_value(accounts_dir, "reserve_credits", realm)


def set_reserve_credits(accounts_dir, value):
    """Persist the guard threshold. Returns the stored value."""
    return set_limit(accounts_dir, "reserve_credits", "global", value)["global"]


def daily_token_limit(accounts_dir, realm=None):
    """Global daily guard: an account that already burned this many tokens
    today stays idle until local midnight.

    Zero disables the guard, which keeps installs that predate the setting
    behaving exactly as before.
    """
    return limit_value(accounts_dir, "daily_token_limit", realm)


def set_daily_token_limit(accounts_dir, value):
    """Persist the daily token threshold. Returns the stored value."""
    return set_limit(accounts_dir, "daily_token_limit", "global", value)["global"]


def daily_credit_limit(accounts_dir, realm=None):
    """Daily credit guard: an account that already spent this many credits
    today serves free models only until local midnight, so a client that
    would keep burning credits on paid models rotates to another account
    instead of spending the whole balance.

    Zero disables the guard, which keeps installs that predate the setting
    behaving exactly as before.
    """
    return limit_value(accounts_dir, "daily_credit_limit", realm)


def set_daily_credit_limit(accounts_dir, value):
    """Persist the daily credit threshold. Returns the stored value."""
    return set_limit(accounts_dir, "daily_credit_limit", "global", value)["global"]


def model_daily_token_limit(accounts_dir, realm=None):
    """Per-model daily guard: an account that already burned this many
    tokens today on ONE model stops being handed out for that model until
    local midnight, while every other model keeps working.

    Zero disables the guard, which keeps installs that predate the setting
    behaving exactly as before.
    """
    return limit_value(accounts_dir, "model_daily_token_limit", realm)


def set_model_daily_token_limit(accounts_dir, value):
    """Persist the per-model daily token threshold. Returns the stored value."""
    return set_limit(accounts_dir, "model_daily_token_limit", "global", value)["global"]


def expiring_window_days(accounts_dir, realm=None):
    """Window, in days, inside which an account's soonest-expiring credit
    package makes the pool hand that account out first, so credits about to
    lapse are spent before they are lost.

    Zero disables the preference and dispatch falls back to a plain
    round-robin; the shipped default is 7 days.
    """
    return limit_value(accounts_dir, "expiring_window_days", realm)


def set_expiring_window_days(accounts_dir, value):
    """Persist the window. Returns the stored value."""
    return set_limit(accounts_dir, "expiring_window_days", "global", value)["global"]


def credits_refresh_hours(accounts_dir):
    """How stale a credit balance may get before the background refresher
    updates it, in hours.

    The dispatch preference reads the balance, and only the sign-in and
    daily-activity tasks used to refresh it, so an account could be judged on a
    balance days old - or on whatever was on disk when the process started.
    Zero disables the refresher. Anything not a number falls back to the
    default, so a hand-edited settings.json cannot wedge the loop.
    """
    with _lock:
        data = load(accounts_dir)
        raw = data.get(CREDITS_REFRESH_HOURS_KEY)
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_CREDITS_REFRESH_HOURS
    if value < 0:
        return DEFAULT_CREDITS_REFRESH_HOURS
    return min(value, MAX_CREDITS_REFRESH_HOURS)


def set_credits_refresh_hours(accounts_dir, value):
    """Persist the refresh TTL. Returns the stored value."""
    try:
        hours = float(value)
    except (TypeError, ValueError):
        hours = 0.0
    hours = max(0.0, min(MAX_CREDITS_REFRESH_HOURS, hours))
    with _lock:
        data = load(accounts_dir)
        data[CREDITS_REFRESH_HOURS_KEY] = hours
        save(accounts_dir, data)
    return hours


def keep_backups(accounts_dir):
    """How many update backups to retain, 0-3.

    Read by the update path after every success (prune) and by the panel before
    it offers a rollback, so a missing or hand-edited value must never be
    something the callers have to guard: anything that is not an int reads as
    the default, and the result is always inside 0..MAX_KEEP_BACKUPS.
    """
    with _lock:
        raw = load(accounts_dir).get(KEEP_BACKUPS_KEY)
    if raw is None or isinstance(raw, bool):
        return DEFAULT_KEEP_BACKUPS
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_KEEP_BACKUPS
    return max(0, min(MAX_KEEP_BACKUPS, value))


def set_keep_backups(accounts_dir, value):
    """Persist the backup retention count. Returns the stored value."""
    try:
        keep = int(value)
    except (TypeError, ValueError):
        keep = DEFAULT_KEEP_BACKUPS
    keep = max(0, min(MAX_KEEP_BACKUPS, keep))
    with _lock:
        data = load(accounts_dir)
        data[KEEP_BACKUPS_KEY] = keep
        save(accounts_dir, data)
    return keep


#: 后台排程时段（CST 24 小时制）。默认值与旧版硬编码完全一致，老安装行为不变。
DEFAULT_SCHEDULE_HOURS = {
    "checkin": [9, 21],
    "travel": [9, 21],
    "keepalive": [22],
    "cat": [1],
}
SCHEDULE_KEYS = ("checkin", "travel", "keepalive", "cat")


def _normalize_hours(value):
    """Coerce a list / comma string into sorted unique hours 0-23, or None."""
    if isinstance(value, str):
        raw = value.split(",")
    elif isinstance(value, (list, tuple)):
        raw = list(value)
    else:
        return None
    out = set()
    for item in raw:
        if isinstance(item, bool):
            continue
        try:
            hour = int(str(item).strip())
        except (TypeError, ValueError):
            continue
        if 0 <= hour <= 23:
            out.add(hour)
    return sorted(out) if out else None


def schedule_hours(accounts_dir):
    """Background schedule hours, falling back per key to the legacy defaults.

    Missing / invalid / out-of-range / empty entries fall back to the default
    for that key, so a hand-edited settings.json cannot stop the scheduler.
    Comma-separated strings are accepted like the other settings readers.
    """
    raw = load(accounts_dir).get("schedule")
    if not isinstance(raw, dict):
        raw = {}
    out = {}
    for key in SCHEDULE_KEYS:
        hours = _normalize_hours(raw.get(key))
        out[key] = hours if hours is not None else list(DEFAULT_SCHEDULE_HOURS[key])
    return out


def set_schedule_hours(accounts_dir, value):
    """Persist a partial schedule update; returns the normalized full schedule.

    Unknown keys are ignored. A supplied key must contain at least one valid
    hour, otherwise ValueError is raised so the caller can return a readable
    400 instead of storing a schedule that silently does nothing.
    """
    if not isinstance(value, dict):
        raise ValueError("schedule must be an object")
    with _lock:
        data = load(accounts_dir)
        current = data.get("schedule")
        if not isinstance(current, dict):
            current = {}
        # Keep keys this function does not own (schedule.daily_chat), so
        # editing the hourly grid cannot silently drop the web-activity times.
        merged = dict(current)
        for key in SCHEDULE_KEYS:
            if key in value:
                hours = _normalize_hours(value.get(key))
                if hours is None:
                    raise ValueError("schedule.%s must contain hours 0-23" % key)
                merged[key] = hours
            else:
                hours = _normalize_hours(current.get(key))
                merged[key] = hours if hours is not None else list(DEFAULT_SCHEDULE_HOURS[key])
        data["schedule"] = merged
        save(accounts_dir, data)
    return merged


#: 网页活跃（国际版每日活跃）的独立时段，HH:MM。空表示跟随 checkin 整点，
#: 与旧版行为一致。24 个时段已经覆盖一整天的每个小时。
DAILY_CHAT_TIMES_MAX = 24


def _normalize_times(value):
    """Coerce a list / comma string into sorted unique HH:MM strings, or None.

    Full-width colons are accepted (the panel and a Chinese keyboard produce
    them); anything that is not a two-part clock time is dropped. None means
    "no valid entry", which the caller treats as a validation error on write
    and as "unset" on read.
    """
    if isinstance(value, str):
        raw = re.split(r"[,，\s]+", value.strip()) if value.strip() else []
    elif isinstance(value, (list, tuple)):
        raw = list(value)
    else:
        return None
    out = set()
    for item in raw:
        text = str(item or "").strip().replace("：", ":")
        if not text:
            continue
        parts = text.split(":")
        if len(parts) != 2:
            continue
        try:
            hour = int(parts[0])
            minute = int(parts[1])
        except (TypeError, ValueError):
            continue
        if 0 <= hour <= 23 and 0 <= minute <= 59:
            out.add("%02d:%02d" % (hour, minute))
    return sorted(out)[:DAILY_CHAT_TIMES_MAX] if out else None


def daily_chat_times(accounts_dir):
    """The web-activity slots; [] means "follow the checkin hours"."""
    raw = load(accounts_dir).get("schedule")
    if not isinstance(raw, dict):
        return []
    return _normalize_times(raw.get("daily_chat")) or []


def set_daily_chat_times(accounts_dir, value):
    """Persist the web-activity slots; an empty value clears them.

    Returns the normalized list. Invalid non-empty input raises ValueError so
    the caller can answer 400 instead of storing a schedule that does nothing.
    """
    empty = False
    if isinstance(value, str):
        empty = not value.strip()
    elif isinstance(value, (list, tuple)):
        empty = not value
    if empty:
        times = []
    else:
        times = _normalize_times(value)
        if times is None:
            raise ValueError("schedule.daily_chat must be HH:MM times")
    with _lock:
        data = load(accounts_dir)
        current = data.get("schedule")
        if not isinstance(current, dict):
            current = {}
        if times:
            current["daily_chat"] = times
        else:
            current.pop("daily_chat", None)
        data["schedule"] = current
        save(accounts_dir, data)
    return times


def section_max_height(accounts_dir):
    """Panel window height cap in pixels; 0 means no limit.

    Anything that is not a whole number falls back to the default, so a
    hand-edited settings.json cannot leave the dashboard with windows a pixel
    tall; a value past MAX_SECTION_MAX_HEIGHT is clamped, not rejected. bool is
    checked first on purpose: it is an int subclass, and True would otherwise
    read as a 1px cap.
    """
    with _lock:
        raw = load(accounts_dir).get(SECTION_MAX_HEIGHT_KEY)
    if isinstance(raw, bool):
        return DEFAULT_SECTION_MAX_HEIGHT
    try:
        value = int(raw)
    except (TypeError, ValueError, OverflowError):
        # OverflowError is its own case: json.loads turns 1e400 into inf, and
        # int(inf) raises it - one broken line must not 500 the settings view.
        return DEFAULT_SECTION_MAX_HEIGHT
    if value < 0:
        return DEFAULT_SECTION_MAX_HEIGHT
    return min(value, MAX_SECTION_MAX_HEIGHT)


def set_section_max_height(accounts_dir, value):
    """Persist the cap. Returns the stored value."""
    if isinstance(value, bool):
        number = DEFAULT_SECTION_MAX_HEIGHT
    else:
        try:
            number = int(value)
        except (TypeError, ValueError, OverflowError):
            number = DEFAULT_SECTION_MAX_HEIGHT
    number = max(0, min(MAX_SECTION_MAX_HEIGHT, number))
    with _lock:
        data = load(accounts_dir)
        data[SECTION_MAX_HEIGHT_KEY] = number
        save(accounts_dir, data)
    return number


# 一键配置写进客户端的模型清单（DSH / OpenCode / Crush / ZCode 会把这份清单
# 抄进自己的配置）。键不存在表示「从未选过」：面板默认全部不勾选，一键配置
# 退回完整目录；显式保存空列表表示「用户全部取消」，一键配置会拒绝写空清单
# ——空清单会生成一个没有模型的 provider，客户端直接不可用。
AGENT_MODELS_KEY = "agent_models"
MODEL_ALIASES_KEY = "model_aliases"


def _clean_model_aliases(raw):
    """Normalise an alias table to ``{lowercase alias: target}``.

    ``model_aliases`` predates the current tree and appears in existing
    settings files as a plain object.  Accept that shape plus the common
    ``[{"from": ..., "to": ...}]`` spelling, but never let a malformed entry
    turn a request into a 500: unknown shapes are ignored.
    """
    out = {}
    pairs = []
    if isinstance(raw, dict):
        pairs = list(raw.items())
    elif isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict):
                continue
            source = item.get("from") or item.get("alias") or item.get("name")
            target = item.get("to") or item.get("target") or item.get("model")
            pairs.append((source, target))
    for source, target in pairs:
        alias = str(source or "").strip().lower()
        model = str(target or "").strip()
        if alias and model and alias != model.lower():
            out[alias] = model
    return out


def model_aliases(accounts_dir):
    """Read the operator-maintained model alias table."""
    raw = load(accounts_dir).get(MODEL_ALIASES_KEY)
    return _clean_model_aliases(raw)
# 清单写进客户端配置后会被逐条展开；200 条已远超任何出口的模型数，上限只挡
# 手编 settings.json 把客户端配置撑爆。
MAX_AGENT_MODELS = 200


def _clean_agent_models(models):
    """清洗模型 id 列表：只留非空字符串、去重保序、限量。"""
    out = []
    seen = set()
    if not isinstance(models, (list, tuple)):
        return out
    for item in models:
        if not isinstance(item, str):
            continue
        mid = item.strip()
        if not mid or mid in seen:
            continue
        seen.add(mid)
        out.append(mid)
        if len(out) >= MAX_AGENT_MODELS:
            break
    return out


def agent_model_selection(accounts_dir):
    """面板勾选的模型 id；None 表示还没保存过（与空列表语义不同）。

    None 让一键配置退回完整目录（升级前的老安装行为）；[] 是用户明确全部
    取消，一键配置会拒绝写一个空的模型清单。
    """
    with _lock:
        data = load(accounts_dir)
    raw = data.get(AGENT_MODELS_KEY)
    if not isinstance(raw, list):
        # 手编坏了的键（字符串 / 对象 / null）按「没保存过」处理：宁可按老行为
        # 退回完整目录，也不要因为一条脏数据让一键配置永远拒绝写模型清单。
        return None
    return _clean_agent_models(raw)


def set_agent_model_selection(accounts_dir, models):
    """保存勾选并返回清洗后的列表；空列表也会落盘（它的语义是「全不勾」）。"""
    cleaned = _clean_agent_models(models)
    with _lock:
        data = load(accounts_dir)
        data[AGENT_MODELS_KEY] = cleaned
        save(accounts_dir, data)
    return cleaned


def _clamp_refresh_minutes(value):
    """A month is well past "often enough"; the cap keeps a typo from parking
    the next refresh beyond any horizon the panel can show."""
    return max(0.0, min(MAX_PRICING_REFRESH_MINUTES, value))


def _migrate_pricing_refresh(data, accounts_dir):
    """(found, minutes) - convert a pre-minutes settings.json in place.

    `pricing_refresh_hours` used to hold hours. Reading it as minutes would
    turn 6 hours into 6 minutes, so the value is multiplied by 60 here, written
    under the new key and the old key dropped - one time, on the first read
    after the upgrade. A value that is not a number just loses the stale key
    and falls back to the default; a legacy 0 still means "off".
    """
    legacy = data.pop(LEGACY_PRICING_REFRESH_HOURS_KEY, None)
    if legacy is None:
        return False, None
    try:
        minutes = _clamp_refresh_minutes(float(legacy) * 60.0)
    except (TypeError, ValueError):
        minutes = None
    else:
        data[PRICING_REFRESH_MINUTES_KEY] = minutes
    try:
        save(accounts_dir, data)
    except Exception:
        # A read-only accounts dir must not take the panel down; the converted
        # value is still returned, and the next read simply migrates again.
        pass
    return True, minutes


def pricing_refresh_minutes(accounts_dir):
    """How often the gateway refreshes the OpenRouter price history, in minutes.

    Zero disables the refresh, which keeps installs that predate the setting
    on the bundled snapshot. A settings.json written before the unit changed
    carries `pricing_refresh_hours`, migrated here on first read (see
    `_migrate_pricing_refresh`). Anything not a number falls back to the
    default, so a hand-edited settings.json cannot wedge the refresh loop.
    """
    with _lock:
        data = load(accounts_dir)
        raw = data.get(PRICING_REFRESH_MINUTES_KEY)
        if raw is None:
            found, minutes = _migrate_pricing_refresh(data, accounts_dir)
            if not found:
                return DEFAULT_PRICING_REFRESH_MINUTES
            if minutes is None:
                return DEFAULT_PRICING_REFRESH_MINUTES
            return minutes
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return DEFAULT_PRICING_REFRESH_MINUTES
    return value if value > 0 else 0.0


def set_pricing_refresh_minutes(accounts_dir, value):
    """Persist the refresh interval in minutes. Returns the stored value."""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return pricing_refresh_minutes(accounts_dir)
    value = _clamp_refresh_minutes(value)
    with _lock:
        data = load(accounts_dir)
        data[PRICING_REFRESH_MINUTES_KEY] = value
        # The minutes key is the one in force; a leftover legacy key would only
        # confuse a later rollback into reading a stale interval.
        data.pop(LEGACY_PRICING_REFRESH_HOURS_KEY, None)
        save(accounts_dir, data)
    return value


def pricing_variant_inherit(accounts_dir):
    """Whether a model name may inherit its price from a suffix-stripped base.

    On unless the operator turns it off: a hub model carrying a channel suffix
    (`deepseek-r1-0528-lkeap`) is the same entity as its base model upstream,
    and without this the gateway would show "未定价" for a model it can price
    exactly. Off restores the previous behaviour - only the override table and
    an exact name match can price a model - so an install that wants the
    strictest possible rule keeps it. A settings.json that predates the key
    reads back as on, which is the default this ships with.
    """
    value = load(accounts_dir).get(PRICING_VARIANT_INHERIT_KEY)
    return True if value is None else value is True


def set_pricing_variant_inherit(accounts_dir, enabled):
    """Persist the variant-inheritance switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[PRICING_VARIANT_INHERIT_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def pricing_enabled(accounts_dir):
    """Master switch for the OpenRouter price estimation, on unless turned off.

    Off disables the feature end to end: no price fetch, no policy table, no
    per-row cost and no cost columns. A settings.json that predates the key
    reads back as on, which is the behaviour every install ships with - the
    switch only exists to let an operator turn the whole thing off.
    """
    value = load(accounts_dir).get(PRICING_ENABLED_KEY)
    return True if value is None else value is True


def set_pricing_enabled(accounts_dir, enabled):
    """Persist the master switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[PRICING_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def ui_language(accounts_dir):
    """Instance-wide default UI language (zh / zh-Hant / en)."""
    value = load(accounts_dir).get(UI_LANGUAGE_KEY)
    if isinstance(value, str) and value in UI_LANGUAGE_VALUES:
        return value
    return UI_LANGUAGE_DEFAULT


def set_ui_language(accounts_dir, value):
    """Persist the instance-wide default UI language."""
    if not isinstance(value, str) or value not in UI_LANGUAGE_VALUES:
        raise ValueError("ui_language must be zh, zh-Hant or en")
    with _lock:
        data = load(accounts_dir)
        data[UI_LANGUAGE_KEY] = value
        save(accounts_dir, data)
    return value


UPSTREAM_DEFAULTS = {
    "header_timeout_seconds": 120,
    "idle_timeout_seconds": 300,
    "device_token": "",
    "device_token_file": "",
}


def validate_upstream_patch(raw):
    """Strict validation for a panel-saved upstream patch."""
    out = {}
    for key, value in (raw or {}).items():
        if key in ("header_timeout_seconds", "idle_timeout_seconds"):
            if isinstance(value, bool) or not isinstance(value, int):
                raise ValueError("%s must be a whole number of seconds" % key)
            if value < 1:
                raise ValueError("%s cannot be less than 1" % key)
            out[key] = value
        elif key in ("device_token", "device_token_file"):
            if not isinstance(value, str):
                raise ValueError("%s must be a string" % key)
            out[key] = value.strip()
        else:
            raise ValueError("unknown upstream setting %r" % key)
    return out


def upstream_config(accounts_dir):
    """Chat socket timeouts and the optional X-Device-Token source."""
    stored = load(accounts_dir).get("upstream")
    stored = stored if isinstance(stored, dict) else {}
    out = {}
    for key, default in UPSTREAM_DEFAULTS.items():
        value = stored.get(key, default)
        if key in ("header_timeout_seconds", "idle_timeout_seconds"):
            out[key] = (value if isinstance(value, int) and not isinstance(value, bool)
                        and value >= 1 else default)
        else:
            out[key] = value.strip() if isinstance(value, str) else default
    return out


def set_upstream_config(accounts_dir, cfg):
    """Persist the upstream settings. Returns the stored config."""
    current = upstream_config(accounts_dir)
    if isinstance(cfg, dict):
        current.update({k: v for k, v in cfg.items() if k in UPSTREAM_DEFAULTS})
    clean = validate_upstream_patch(current)
    with _lock:
        data = load(accounts_dir)
        data["upstream"] = deep_merge(data.get("upstream"), clean)
        save(accounts_dir, data)
    return clean


def max_payload_mb(accounts_dir):
    value = load(accounts_dir).get("max_payload_mb")
    return value if isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= 256 else None


def set_max_payload_mb(accounts_dir, value):
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 256:
        raise ValueError("max_payload_mb must be an integer between 1 and 256")
    with _lock:
        data = load(accounts_dir)
        data["max_payload_mb"] = value
        save(accounts_dir, data)
    return value


USAGE_DEFAULTS = {
    "hour_keep_hours": 48,
    "day_keep_days": 32,
}

# 上限只是防手滑：面板输入框贴错位数会把 checkpoint 撑到几百 MB，而它每推进
# 一点就要整份重写——路由器上 flash 写入慢且费寿命。两周的小时层、一年的日桶
# 已经远超任何窗口够得到的范围。
USAGE_LIMITS = {
    "hour_keep_hours": 24 * 14,
    "day_keep_days": 366,
}

def validate_usage_patch(raw):
    """Strict validation for a panel-saved aggregate-retention patch."""
    out = {}
    for key, value in (raw or {}).items():
        if key not in USAGE_DEFAULTS:
            raise ValueError("unknown usage setting %r" % key)
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("%s must be a whole number" % key)
        if value < 1:
            raise ValueError("%s cannot be less than 1" % key)
        if value > USAGE_LIMITS[key]:
            raise ValueError("%s cannot be more than %d" % (key, USAGE_LIMITS[key]))
        out[key] = value
    return out

def usage_config(accounts_dir):
    """聚合保留窗口（小时层 / 日桶）。面板没设过就是内置默认值。"""
    stored = load(accounts_dir).get("usage")
    stored = stored if isinstance(stored, dict) else {}
    out = {}
    for key, default in USAGE_DEFAULTS.items():
        value = stored.get(key, default)
        if (isinstance(value, bool) or not isinstance(value, int)
                or value < 1 or value > USAGE_LIMITS[key]):
            value = default
        out[key] = value
    return out

def set_usage_config(accounts_dir, patch):
    """Persist a validated aggregate-retention patch."""
    clean = validate_usage_patch(patch)
    with _lock:
        data = load(accounts_dir)
        data["usage"] = deep_merge(data.get("usage"), clean)
        save(accounts_dir, data)
    return clean

# ---------------------------------------------------------------- 媒体能力（生图 / 生视频）
#
# **默认全关**：这是本仓库里唯一一项「模型自己决定花钱」的能力——一次生图约 5.7
# 积分、一条 5 秒视频 57~129 积分，直接扣账号积分而不经 token 计费，宿主也没有
# 「调用前先确认」的机制。所以升级不能附赠它，必须是操作者显式打开的。
#
# 每一项都有上限（与 USAGE_LIMITS 同一套理由）：面板输入框贴错一位数就会把
# 「每分钟 6 次」变成「每分钟 600 次」，那等于关掉了这道闸。

MEDIA_DEFAULTS = {
    # 总闸。false 时媒体路由**根本不存在**（404），不是 403——少一个探测面。
    "enabled": False,
    # 媒体只走哪个区。默认国内版：已取证的媒体目录在 cn；intl 有 hy-image-3.5
    # 与 kling-video-v3，但没有 intl 账号时选它只会得到「该区没有可用账号」。
    "realm": "cn",
    # 出站身份：desktop（跟账号自身）或 cli。P0 取证之后把结论落到这里，
    # 换默认值不需要改代码路径。
    "identity": "desktop",
    # 每个 API Key 每分钟最多几次生图。6 次/分钟 × 5.71 积分 ≈ 34 积分/分钟。
    "image_max_per_minute": 6,
    # 视频时长上限（秒）。与目录的 maxSeconds 取小值。
    "video_max_seconds": 15,
    # 每个 API Key 每天最多在媒体上花多少积分；0 = 不限。
    # 这是第二道闸门：key 级防「一个客户端把整个池子烧光」，账号级的
    # daily_credit_limit 防「某个账号被烧穿」。两层都过才派发。
    # **默认不限**（0）。设一个有限的默认值等于替用户决定花多少，而失败模式很难看：
    # 跑到一半撞额度，客户端只看到 402，还得自己猜是不是该改配置。
    "daily_credits_per_key": 0,
    # 同时跑几条生视频。超过就排队（不提交上游、不扣费），等有任务结束再自动提交。
    # 3 是"三条并行、各占一个账号"的默认：再多会放大同一账号的风控面，
    # 而账号数不足时排队比硬塞更划算。
    "video_concurrency": 3,
}

MEDIA_LIMITS = {
    "image_max_per_minute": 60,
    "video_max_seconds": 60,
    "daily_credits_per_key": 100000,
    # 上限压在媒体并发槽（4）以内：再大也没有东西去跑。
    "video_concurrency": 8,
}

#: 每个数值项的合法下界。生图次数与视频时长至少 1 秒/次；每日额度允许 0（不限）。
MEDIA_MINIMUMS = {
    "image_max_per_minute": 1,
    "video_max_seconds": 1,
    "daily_credits_per_key": 0,
    "video_concurrency": 1,
}

MEDIA_REALMS = ("cn", "intl")
MEDIA_IDENTITIES = ("desktop", "cli")


def validate_media_patch(raw):
    """严格校验面板提交的媒体设置补丁。

    未知键**报错**而不是忽略：静默忽略会让前端拼错字段名时显示「保存成功」、
    而实际什么都没存——那是最难查的一类问题。
    """
    out = {}
    for key, value in (raw or {}).items():
        if key not in MEDIA_DEFAULTS:
            raise ValueError("unknown media setting %r" % key)
        if key == "enabled":
            if not isinstance(value, bool):
                raise ValueError("enabled must be true or false")
            out[key] = value
            continue
        if key == "realm":
            if value not in MEDIA_REALMS:
                raise ValueError("realm must be one of %s" % ", ".join(MEDIA_REALMS))
            out[key] = value
            continue
        if key == "identity":
            if value not in MEDIA_IDENTITIES:
                raise ValueError("identity must be one of %s" % ", ".join(MEDIA_IDENTITIES))
            out[key] = value
            continue
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError("%s must be a whole number" % key)
        if value < MEDIA_MINIMUMS[key]:
            raise ValueError("%s cannot be less than %d" % (key, MEDIA_MINIMUMS[key]))
        if value > MEDIA_LIMITS[key]:
            raise ValueError("%s cannot be more than %d" % (key, MEDIA_LIMITS[key]))
        out[key] = value
    return out


def media_config(accounts_dir, environ=None):
    """媒体设置（带默认值，坏值回落到默认值而不是抛）。

    `WB_MEDIA_ENABLED=1` 可临时打开总闸，供 CI 与冒烟用。**只有总闸**吃这个环境
    变量：限额要是能被环境变量改大，「谁把它调大了」就变成不可查的问题。
    """
    stored = load(accounts_dir).get("media")
    stored = stored if isinstance(stored, dict) else {}
    out = {}
    for key, default in MEDIA_DEFAULTS.items():
        value = stored.get(key, default)
        if key == "enabled":
            out[key] = value if isinstance(value, bool) else default
        elif key == "realm":
            out[key] = value if value in MEDIA_REALMS else default
        elif key == "identity":
            out[key] = value if value in MEDIA_IDENTITIES else default
        elif (isinstance(value, bool) or not isinstance(value, int)
              or value < MEDIA_MINIMUMS[key] or value > MEDIA_LIMITS[key]):
            out[key] = default
        else:
            out[key] = value
    environ = os.environ if environ is None else environ
    if str(environ.get("WB_MEDIA_ENABLED") or "").strip() == "1":
        out["enabled"] = True
    return out


def set_media_config(accounts_dir, patch):
    """持久化一份校验过的媒体设置补丁。"""
    clean = validate_media_patch(patch)
    with _lock:
        data = load(accounts_dir)
        data["media"] = deep_merge(data.get("media"), clean)
        save(accounts_dir, data)
    return clean

PROMPT_DEFAULTS = {
    "mode": "passthrough",
    "file": "",
    "text": "",
}
#: 在线全局提示词的上限。比文件路径宽松得多，但仍然有界：一个手滑的粘贴
#: 不该让每个请求都多背几百 KB。
PROMPT_TEXT_MAX = 64 * 1024


def validate_prompt_patch(raw):
    """Strict validation for a panel-saved prompt patch."""
    out = {}
    for key, value in (raw or {}).items():
        if key == "mode":
            if not isinstance(value, str):
                raise ValueError("prompt mode must be a string")
            mode = value.strip().lower()
            if mode not in ("passthrough", "custom", "append"):
                raise ValueError("prompt mode must be passthrough, custom or append")
            out["mode"] = mode
        elif key == "file":
            if not isinstance(value, str):
                raise ValueError("prompt file must be a string")
            out["file"] = value.strip()
        elif key == "text":
            if not isinstance(value, str):
                raise ValueError("prompt text must be a string")
            if len(value.encode("utf-8")) > PROMPT_TEXT_MAX:
                raise ValueError("prompt text cannot be more than %d bytes"
                                 % PROMPT_TEXT_MAX)
            out["text"] = value
        else:
            raise ValueError("unknown prompt setting %r" % key)
    return out


def prompt_config(accounts_dir):
    """Gateway system-prompt mode (default passthrough = legacy behaviour)."""
    stored = load(accounts_dir).get("prompt")
    stored = stored if isinstance(stored, dict) else {}
    mode = stored.get("mode", PROMPT_DEFAULTS["mode"])
    if not isinstance(mode, str) or mode.strip().lower() not in (
            "passthrough", "custom", "append"):
        mode = PROMPT_DEFAULTS["mode"]
    else:
        mode = mode.strip().lower()
    file_path = stored.get("file", PROMPT_DEFAULTS["file"])
    if not isinstance(file_path, str):
        file_path = PROMPT_DEFAULTS["file"]
    text = stored.get("text", PROMPT_DEFAULTS["text"])
    if not isinstance(text, str):
        text = PROMPT_DEFAULTS["text"]
    return {"mode": mode, "file": file_path.strip(), "text": text}


def set_prompt_config(accounts_dir, cfg):
    """Persist the prompt settings. Returns the stored config."""
    current = prompt_config(accounts_dir)
    if isinstance(cfg, dict):
        current.update({k: v for k, v in cfg.items() if k in PROMPT_DEFAULTS})
    clean = validate_prompt_patch(current)
    with _lock:
        data = load(accounts_dir)
        data["prompt"] = clean
        save(accounts_dir, data)
    return clean


def enable_anthropic_messages(accounts_dir):
    """Whether Anthropic Messages compatibility layer is enabled via panel settings."""
    return load(accounts_dir).get("enable_anthropic_messages") is True


def set_enable_anthropic_messages(accounts_dir, enabled):
    """Persist the Anthropic Messages toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["enable_anthropic_messages"] = enabled
        save(accounts_dir, data)
    return enabled


def free_model_credit_fallback(accounts_dir):
    """Whether exhausted free models (deepseek-v4.1-flash) can fall back to credit siblings."""
    return load(accounts_dir).get("free_model_credit_fallback") is True


def set_free_model_credit_fallback(accounts_dir, enabled):
    """Persist the free model credit fallback toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["free_model_credit_fallback"] = enabled
        save(accounts_dir, data)
    return enabled


def filter_models_by_key(accounts_dir):
    """Whether /v1/models hides models the requesting key may not use.

    Off by default: the endpoint has always advertised the upstream catalogue,
    and an install that predates this setting keeps behaving exactly as it did.
    When on, a key with a model restriction only sees the models it allows, so
    clients that auto-discover the catalogue cannot pick one that is later
    rejected at request time. Keys without a restriction still see everything.
    """
    return load(accounts_dir).get("filter_models_by_key") is True


def set_filter_models_by_key(accounts_dir, enabled):
    """Persist the /v1/models key filter toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["filter_models_by_key"] = enabled
        save(accounts_dir, data)
    return enabled


def reasoning_effort_map(accounts_dir):
    """Whether an unsupported reasoning_effort is mapped to the model default.

    On by default: clients that expose a fixed level picker keep sending levels
    a model does not accept, and the upstream rejects the whole request. An
    install that predates the setting therefore keeps the new behaviour; only
    an explicit false turns the mapping off.
    """
    return load(accounts_dir).get("reasoning_effort_map") is not False


def set_reasoning_effort_map(accounts_dir, enabled):
    """Persist the reasoning-effort mapping toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["reasoning_effort_map"] = enabled
        save(accounts_dir, data)
    return enabled


def models_only_available(accounts_dir):
    """Whether /v1/models hides models no account in the pool can serve.

    Off by default: the endpoint has always advertised the upstream catalogue,
    and an install that predates this setting keeps that behaviour. When on,
    a PRO-only model is only listed while a paid account exists, and any other
    model needs at least one enabled account in the realm.
    """
    return load(accounts_dir).get("models_only_available") is True


def set_models_only_available(accounts_dir, enabled):
    """Persist the availability filter toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["models_only_available"] = enabled
        save(accounts_dir, data)
    return enabled


def auto_switch_product(accounts_dir):
    """Whether an upstream 429 may rotate an account's outbound identity.

    Off unless the operator turns it on. Rotating identity spends the request's
    retry budget and leaves the account on a channel nobody picked, so the
    gateway does not decide that on its own - and an install that predates the
    setting keeps behaving exactly as it did.
    """
    return load(accounts_dir).get("auto_switch_product") is True


def set_auto_switch_product(accounts_dir, enabled):
    """Persist the auto-switch toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["auto_switch_product"] = enabled
        save(accounts_dir, data)
    return enabled


#: 出站身份自动切换允许落在哪些身份上（默认三条都允许，保持旧行为）。
AUTO_SWITCH_PRODUCTS = ("workbuddy", "vscode", "cli")


def auto_switch_products(accounts_dir):
    """Allowed target identities for the 429 auto-switch.

    Defaults to all three so an install that predates this setting keeps the
    old behaviour. Unknown entries are dropped rather than failing the read.
    """
    raw = load(accounts_dir).get("auto_switch_products")
    if not isinstance(raw, list):
        return list(AUTO_SWITCH_PRODUCTS)
    out = []
    for item in raw:
        if isinstance(item, str) and item in AUTO_SWITCH_PRODUCTS and item not in out:
            out.append(item)
    return out


def set_auto_switch_products(accounts_dir, products):
    """Persist the allowed auto-switch identities. Returns the stored list.

    Raises ValueError for anything that is not a list of known product ids, so
    the panel gets a readable 400 instead of silently storing garbage.
    """
    if not isinstance(products, list):
        raise ValueError("auto_switch_products must be a list")
    clean = []
    for item in products:
        if not isinstance(item, str) or item not in AUTO_SWITCH_PRODUCTS:
            raise ValueError("unknown auto-switch product: %r" % (item,))
        if item not in clean:
            clean.append(item)
    with _lock:
        data = load(accounts_dir)
        data["auto_switch_products"] = clean
        save(accounts_dir, data)
    return clean


#: X-Private-Data is the official client's "may this conversation train the
#: model" declaration. auto keeps the per-identity value the gateway already
#: sends; true/false override it for every identity (issue #516).
IDENTITY_KEY = "identity"
IDENTITY_PRIVATE_DATA_VALUES = ("auto", "true", "false")


def identity_private_data(accounts_dir):
    """The configured X-Private-Data override: auto, true or false."""
    raw = load(accounts_dir).get(IDENTITY_KEY)
    if not isinstance(raw, dict):
        return "auto"
    value = str(raw.get("private_data") or "auto").strip().lower()
    return value if value in IDENTITY_PRIVATE_DATA_VALUES else "auto"


IDENTITY_VERSION_KEYS = (
    "desktop_intl", "desktop_cn", "desktop_cli",
    "vscode_product", "vscode_ide", "cli", "sdk", "node",
)
IDENTITY_VERSION_MAX_LEN = 64
_IDENTITY_VERSION_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._-]{0,63}$")


def _clean_identity_versions(raw):
    out = {}
    if not isinstance(raw, dict):
        return out
    for key in IDENTITY_VERSION_KEYS:
        value = str(raw.get(key) or "").strip()
        if not value:
            continue
        if (len(value.encode("utf-8")) > IDENTITY_VERSION_MAX_LEN
                or not _IDENTITY_VERSION_RE.match(value)):
            raise ValueError("identity_versions.%s must be a version string" % key)
        out[key] = value
    return out


def identity_versions(accounts_dir):
    """Panel-set version overrides; {} means "use the verified defaults"."""
    try:
        return _clean_identity_versions(load(accounts_dir).get("identity_versions"))
    except ValueError:
        return {}


def set_identity_versions(accounts_dir, versions):
    """Persist version overrides; an empty dict clears them."""
    clean = _clean_identity_versions(versions)
    with _lock:
        data = load(accounts_dir)
        if clean:
            data["identity_versions"] = clean
        else:
            data.pop("identity_versions", None)
        save(accounts_dir, data)
    return clean


def identity_config(accounts_dir):
    return {"private_data": identity_private_data(accounts_dir),
            "versions": identity_versions(accounts_dir)}


def set_identity_private_data(accounts_dir, value):
    """Persist the X-Private-Data override. Returns the normalized value."""
    value = str(value or "auto").strip().lower()
    if value not in IDENTITY_PRIVATE_DATA_VALUES:
        raise ValueError("identity.private_data must be auto, true or false")
    with _lock:
        data = load(accounts_dir)
        identity = data.get(IDENTITY_KEY)
        if not isinstance(identity, dict):
            identity = {}
        identity["private_data"] = value
        data[IDENTITY_KEY] = identity
        save(accounts_dir, data)
    return value


def remaining_priority_enabled(accounts_dir):
    """Whether pairs close to their estimated remaining quota are served first.

    Off unless the operator turns it on. The remaining-usage estimate is
    inferred from cap events and the usage log, and preferring the pairs that
    are close to their estimated limit is a deliberate trade: they take a
    visibly larger share of the traffic, which is the point of the preference
    (spend the quota that would otherwise lapse with the window). An install
    that predates the switch keeps the plain round-robin, so nothing changes
    until it is explicitly turned on.
    """
    return load(accounts_dir).get(REMAINING_PRIORITY_ENABLED_KEY) is True


def set_remaining_priority_enabled(accounts_dir, enabled):
    """Persist the remaining-usage priority switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[REMAINING_PRIORITY_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def egress_backoff_enabled(accounts_dir):
    """Whether transient failures are accounted per egress instead of per account.

    Off unless the operator turns it on. Turning it on changes how a transport
    failure or a 502/503/504 is punished: it stops feeding the account breaker
    (30 minutes, doubling to 6h) and instead grows a seconds-level backoff on the
    outbound path the request actually used (see wb_egress). That is the fix for
    issue #271 - a few seconds of link flakiness used to park healthy accounts
    for half an hour - but it is a change to dispatch behaviour, so an install
    that predates the switch keeps the old accounting.
    """
    return load(accounts_dir).get(EGRESS_BACKOFF_ENABLED_KEY) is True


def set_egress_backoff_enabled(accounts_dir, enabled):
    """Persist the egress-level backoff switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[EGRESS_BACKOFF_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled


RESTRICTION_HOLD_SECONDS_KEY = "restriction_hold_seconds"
DEFAULT_RESTRICTION_HOLD_SECONDS = 1800
MAX_RESTRICTION_HOLD_SECONDS = 86400 * 7


def restriction_hold_seconds(accounts_dir):
    """How many seconds the gateway pauses dispatch when upstream reports an
    unusual activity restriction (403 / 11140).

    Defaults to 1800 seconds (30 minutes). When set to 0, restriction hold is
    disabled. Operator can configure custom duration via panel settings.
    """
    val = load(accounts_dir).get(RESTRICTION_HOLD_SECONDS_KEY)
    if isinstance(val, (int, float)) and not isinstance(val, bool) and val >= 0:
        return float(val)
    env_val = os.environ.get("WB_RESTRICTION_HOLD_SECONDS")
    if env_val is not None:
        try:
            return max(0.0, float(env_val))
        except (ValueError, TypeError):
            pass
    return float(DEFAULT_RESTRICTION_HOLD_SECONDS)


def set_restriction_hold_seconds(accounts_dir, value):
    """Persist the restriction hold duration in seconds."""
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
        raise ValueError("restriction_hold_seconds must be a non-negative number")
    if value > MAX_RESTRICTION_HOLD_SECONDS:
        raise ValueError("restriction_hold_seconds exceeds maximum allowed")
    stored = int(value) if float(value).is_integer() else round(float(value), 1)
    with _lock:
        data = load(accounts_dir)
        data[RESTRICTION_HOLD_SECONDS_KEY] = stored
        save(accounts_dir, data)
    return stored


def realm_fallback_enabled(accounts_dir):
    """Whether a throttled international exit may fail over to the domestic one.

    Off unless the operator turns it on, because it crosses a boundary the
    gateway otherwise keeps absolute: an account belongs to one exit, and the
    pool only ever dispatches that exit's accounts (see AccountPool.pick). The
    two exits are separate upstreams with separate quota and separate credit
    ledgers, so serving a request from the other one changes which balance was
    spent.

    It is still worth having: the exits throttle independently. When every
    international account is cooling a model - upstream frequency limit, a used
    up 24h window, or the gateway's own synthesized "usage exceeds frequency
    limit" - the domestic exit can usually serve the same model right away,
    because it is a different host with its own rate limiter.

    The direction is deliberately one-way (intl -> cn). A request that started
    on the domestic exit never fails over to the international one: domestic
    accounts are the cheaper/free side, and silently moving traffic onto the
    international exit would spend a balance the operator did not ask to spend.
    """
    return load(accounts_dir).get(REALM_FALLBACK_ENABLED_KEY) is True


def set_realm_fallback_enabled(accounts_dir, enabled):
    """Persist the cross-exit fallback switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[REALM_FALLBACK_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def log_db_enabled(accounts_dir):
    """Whether runtime logs are also appended to usage/logs.sqlite3.

    Off unless the operator turns it on: with the switch off the log lives only
    in the in-memory ring, exactly as it does upstream, and no database file is
    created. Turning it on starts a durable copy so a crash, a restart or a
    slow-moving incident can still be read back afterwards.
    """
    return load(accounts_dir).get(LOG_DB_ENABLED_KEY) is True


def set_log_db_enabled(accounts_dir, enabled):
    """Persist the log-database switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[LOG_DB_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def _positive_cap(raw, fallback, hard_max):
    """One retention cap read back: a positive whole number, clamped.

    Anything that is not a usable positive integer (a bool, text, 0, a negative,
    a hand-edited 1e400) falls back instead of raising - a broken settings.json
    must not take the log path down with it.
    """
    if isinstance(raw, bool):
        return fallback
    try:
        value = int(raw)
    except (TypeError, ValueError, OverflowError):
        return fallback
    if value <= 0:
        return fallback
    return min(value, hard_max)


def _clearable_cap(value, hard_max):
    """One retention cap on its way to disk: blank or nonsense means "no cap".

    The panel posts an empty string for a field the operator cleared, and 0 is
    the same intent typed out. Both land as None (JSON null), which is what the
    getters read back as "unlimited on this axis".
    """
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    try:
        number = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if number <= 0:
        return None
    return min(number, hard_max)


def log_db_max_rows(accounts_dir):
    """Newest-N row cap for the log database; None means no row cap.

    Absent key reads as None: a fresh install keeps every row until the days
    cap trims it, which is what "rows left blank" asks for.
    """
    data = load(accounts_dir)
    if LOG_DB_MAX_ROWS_KEY not in data:
        return None
    raw = data.get(LOG_DB_MAX_ROWS_KEY)
    if raw is None:
        return None
    return _positive_cap(raw, None, MAX_LOG_DB_MAX_ROWS)


def set_log_db_max_rows(accounts_dir, value):
    """Persist the row cap (blank clears it). Returns the stored value."""
    stored = _clearable_cap(value, MAX_LOG_DB_MAX_ROWS)
    with _lock:
        data = load(accounts_dir)
        data[LOG_DB_MAX_ROWS_KEY] = stored
        save(accounts_dir, data)
    return stored


def log_db_max_days(accounts_dir):
    """Age cap for the log database, in days; None means no age cap.

    Unlike the other two, an absent key reads as the 7-day default: an install
    that has never touched the setting still gets a bounded database. Clearing
    the field on purpose stores None and turns the cap off.
    """
    data = load(accounts_dir)
    if LOG_DB_MAX_DAYS_KEY not in data:
        return DEFAULT_LOG_DB_MAX_DAYS
    raw = data.get(LOG_DB_MAX_DAYS_KEY)
    if raw is None:
        return None
    return _positive_cap(raw, DEFAULT_LOG_DB_MAX_DAYS, MAX_LOG_DB_MAX_DAYS)


def set_log_db_max_days(accounts_dir, value):
    """Persist the age cap (blank clears it). Returns the stored value."""
    stored = _clearable_cap(value, MAX_LOG_DB_MAX_DAYS)
    with _lock:
        data = load(accounts_dir)
        data[LOG_DB_MAX_DAYS_KEY] = stored
        save(accounts_dir, data)
    return stored


def log_db_max_bytes(accounts_dir):
    """File-size cap for the log database, in bytes; None means no size cap.

    Absent key reads as None, like the row cap: the days default is what keeps
    a fresh install bounded, and the size cap is there for a deployment that
    wants a hard ceiling on the file itself.
    """
    data = load(accounts_dir)
    if LOG_DB_MAX_BYTES_KEY not in data:
        return None
    raw = data.get(LOG_DB_MAX_BYTES_KEY)
    if raw is None:
        return None
    return _positive_cap(raw, None, MAX_LOG_DB_MAX_BYTES)


def set_log_db_max_bytes(accounts_dir, value):
    """Persist the size cap (blank clears it). Returns the stored value."""
    stored = _clearable_cap(value, MAX_LOG_DB_MAX_BYTES)
    with _lock:
        data = load(accounts_dir)
        data[LOG_DB_MAX_BYTES_KEY] = stored
        save(accounts_dir, data)
    return stored


def daily_activity_enabled(accounts_dir):
    """Whether the scheduler runs the intl daily activity at all (master switch).

    On unless the operator turns it off: an install that never touched the
    setting keeps the scheduled daily activity exactly as before. Writing
    ``false`` stops it (like ``daily_chat_web``, any stored value other than
    unset / ``true`` reads as off; the panel and API only ever write booleans):
    the scheduled slots, the forced "check now" cycle and the startup catch-up
    all skip it, while the manual per-account / batch buttons in the panel
    still work, because those are explicit operator actions.
    """
    value = load(accounts_dir).get("daily_activity")
    return True if value is None else value is True


def set_daily_activity_enabled(accounts_dir, enabled):
    """Persist the daily-activity master switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["daily_activity"] = enabled
        save(accounts_dir, data)
    return enabled


def daily_chat_web(accounts_dir):
    """Whether the intl daily check-in also opens a web-channel conversation.

    On unless the operator turns it off: the desktop-identity chat completion
    this automation used to send does not register the daily activity, while a
    web conversation does (issues #75, #59). An install that never touched the
    setting keeps the web step, because that is the behaviour that earns the
    credits; the toggle exists so a deployment can opt back into the old
    single-request check-in.
    """
    value = load(accounts_dir).get("daily_chat_web")
    return True if value is None else value is True


def set_daily_chat_web(accounts_dir, enabled):
    """Persist the web-channel toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_web"] = enabled
        save(accounts_dir, data)
    return enabled


#: 网页通道一轮等多久（秒）的默认值。与 wb_accounts.WEB_TURN_TIMEOUT 同值：
#: 没配过的部署保持既有行为，改过的部署按自己配的来。
DAILY_CHAT_WEB_TIMEOUT_DEFAULT = 120
#: 上限只是防手滑：单轮等待再长也不该超过一小时。
DAILY_CHAT_WEB_TIMEOUT_MAX = 3600


def daily_chat_web_timeout(accounts_dir, default=None):
    """Seconds one web-channel round may wait for the session to finish.

    ``default`` is what an unset install gets, so a caller that has its own
    built-in default (the env-overridable ``WB_WEB_TURN_TIMEOUT``) keeps it
    instead of being silently reset to 120 by this setting's existence.
    Anything that is not a whole number in range also falls back to it, so a
    hand-edited settings.json cannot make the scheduler hang on a huge value
    or trip over a string.
    """
    if default is None:
        default = DAILY_CHAT_WEB_TIMEOUT_DEFAULT
    value = load(accounts_dir).get("daily_chat_web_timeout")
    if (isinstance(value, bool) or not isinstance(value, int)
            or value < 1 or value > DAILY_CHAT_WEB_TIMEOUT_MAX):
        return default
    return value


def set_daily_chat_web_timeout(accounts_dir, seconds):
    """Persist the per-attempt wait. Returns the stored whole number of seconds."""
    if isinstance(seconds, bool) or not isinstance(seconds, int):
        raise ValueError("daily_chat_web_timeout must be a whole number of seconds")
    if seconds < 1:
        raise ValueError("daily_chat_web_timeout cannot be less than 1")
    if seconds > DAILY_CHAT_WEB_TIMEOUT_MAX:
        raise ValueError("daily_chat_web_timeout cannot be more than %d"
                         % DAILY_CHAT_WEB_TIMEOUT_MAX)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_web_timeout"] = seconds
        save(accounts_dir, data)
    return seconds


#: 「还没跑到 turn 就失败」（建会话 5xx、取沙箱失败）时的退避基数上限（秒）。
#: 那一轮只花掉几百毫秒、不消耗任何等待预算，所以退避是唯一的节奏；但它同样
#: 有上限——一个卡住的上游会让每个候选都睡这么久。
DAILY_CHAT_WEB_RETRY_BACKOFF_MAX = 60
#: 没配过时的退避基数（秒）。调用方另有内置默认（wb_accounts.WEB_RETRY_BACKOFF，
#: 吃 WB_WEB_RETRY_BACKOFF 环境变量）时会把自己的默认传进来。
DAILY_CHAT_WEB_RETRY_BACKOFF_DEFAULT = 5


def daily_chat_web_retry_backoff(accounts_dir, default=None):
    """Seconds to wait before retrying a round that never reached the turn.

    0 disables the backoff, which is the pre-1.7.x timing (retry immediately).
    ``default`` is what an unset install gets, so a caller that has its own
    built-in default (the env-overridable ``WB_WEB_RETRY_BACKOFF``) keeps it.
    Anything that is not a whole number in range also falls back to it.
    """
    if default is None:
        default = DAILY_CHAT_WEB_RETRY_BACKOFF_DEFAULT
    value = load(accounts_dir).get("daily_chat_web_retry_backoff")
    if (isinstance(value, bool) or not isinstance(value, int)
            or value < 0 or value > DAILY_CHAT_WEB_RETRY_BACKOFF_MAX):
        return default
    return value


def set_daily_chat_web_retry_backoff(accounts_dir, seconds):
    """Persist the backoff base. Returns the stored whole number of seconds."""
    if isinstance(seconds, bool) or not isinstance(seconds, int):
        raise ValueError(
            "daily_chat_web_retry_backoff must be a whole number of seconds")
    if seconds < 0:
        raise ValueError("daily_chat_web_retry_backoff cannot be negative")
    if seconds > DAILY_CHAT_WEB_RETRY_BACKOFF_MAX:
        raise ValueError("daily_chat_web_retry_backoff cannot be more than %d"
                         % DAILY_CHAT_WEB_RETRY_BACKOFF_MAX)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_web_retry_backoff"] = seconds
        save(accounts_dir, data)
    return seconds


#: 随机池的条数上限：内置 300 条全选 + 200 条自定义。池里存的是完整列表
#: （选中的内置提示词与自定义提示词混在一起），所以上限按两者之和给。
DAILY_CHAT_WEB_PROMPTS_MAX = 500
#: 单条提示词的长度上限（UTF-8 字节）。与 Go 版的 200 字节保持一致。
DAILY_CHAT_WEB_PROMPT_MAX_LEN = 200


def _clean_web_prompts(value):
    """Coerce a list / newline string into deduplicated prompt lines."""
    if isinstance(value, str):
        raw = value.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    elif isinstance(value, (list, tuple)):
        raw = list(value)
    else:
        return []
    out = []
    seen = set()
    for item in raw:
        prompt = str(item or "").strip()
        if not prompt:
            continue
        if len(prompt.encode("utf-8")) > DAILY_CHAT_WEB_PROMPT_MAX_LEN:
            continue
        if prompt in seen:
            continue
        seen.add(prompt)
        out.append(prompt)
        if len(out) >= DAILY_CHAT_WEB_PROMPTS_MAX:
            break
    return out


def daily_chat_web_random_prompt(accounts_dir):
    """Whether the web leg draws a random prompt instead of always sending Hi.

    Off by default: the daily activity is one throwaway turn, and an install
    that predates the setting keeps sending the same one-word prompt it always
    did.
    """
    return load(accounts_dir).get("daily_chat_web_random_prompt") is True


def set_daily_chat_web_random_prompt(accounts_dir, enabled):
    """Persist the random-prompt toggle. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_web_random_prompt"] = enabled
        save(accounts_dir, data)
    return enabled


def daily_chat_web_prompts(accounts_dir):
    """User-added prompts, appended to the built-in pool when the draw runs."""
    return _clean_web_prompts(load(accounts_dir).get("daily_chat_web_prompts"))


def set_daily_chat_web_prompts(accounts_dir, prompts):
    """Persist the custom prompt lines. Returns the normalized list."""
    cleaned = _clean_web_prompts(prompts)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_web_prompts"] = cleaned
        save(accounts_dir, data)
    return cleaned
#: 网页活跃同时跑几个账号。默认 1 = 保持逐账号串行的旧行为；调大后按这个
#: 上限并发跑当天的国际版活跃，上限只是防手滑（每个并发都是一次真实上游会话）。
DAILY_CHAT_WEB_CONCURRENCY_DEFAULT = 1
DAILY_CHAT_WEB_CONCURRENCY_MAX = 10


def daily_chat_web_concurrency(accounts_dir, default=None):
    """How many intl daily-activity conversations may run at once.

    ``default`` is what an unset install gets (1, the serial behaviour), so a
    caller with its own built-in default keeps it. Out-of-range or non-integer
    values fall back to it too, so a hand-edited settings.json cannot turn the
    sweep into an unbounded burst.
    """
    if default is None:
        default = DAILY_CHAT_WEB_CONCURRENCY_DEFAULT
    value = load(accounts_dir).get("daily_chat_web_concurrency")
    if (isinstance(value, bool) or not isinstance(value, int)
            or value < 1 or value > DAILY_CHAT_WEB_CONCURRENCY_MAX):
        return default
    return value


def set_daily_chat_web_concurrency(accounts_dir, value):
    """Persist the concurrency limit. Returns the stored whole number."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError("daily_chat_web_concurrency must be a whole number")
    if value < 1:
        raise ValueError("daily_chat_web_concurrency cannot be less than 1")
    if value > DAILY_CHAT_WEB_CONCURRENCY_MAX:
        raise ValueError("daily_chat_web_concurrency cannot be more than %d"
                         % DAILY_CHAT_WEB_CONCURRENCY_MAX)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_web_concurrency"] = value
        save(accounts_dir, data)
    return value


# ---------------------------------------------------------------- 每日活跃预算模型
# 网页活跃过去有六个互相覆盖的旋钮：最多尝试次数、首轮等待、失败重试、失败后按
# 模型组合回退、回退组合、建会话失败退避。它们其实共同决定同一个乘积 —— 一次打卡
# 最长占住调度器多久；而面板把它们画成六个独立开关，于是「勾选的模型不生效」
# 「次数设了 1 还是跑 6 次」这类组合根本看不出来。
#
# 现在只留两个真正的输入：
#   * daily_chat_models —— 有序候选序列：第一个是首选，其余是回退；空 = 自动
#   * daily_chat_budget —— 单账号总预算（秒），0 = 不限制（回到旧行为）
# 尝试轮数由候选序列推出，建会话退避与每轮等待都从同一个预算里扣，所以不可能
# 再出现「次数 × 等待 × 回退轮次」失控的组合。
DAILY_CHAT_BUDGET_DEFAULT = 600
DAILY_CHAT_BUDGET_MAX = 7200
#: 剩余预算低于这个值就不再开新的一轮：一轮至少要能等到会话真的跑起来。
DAILY_CHAT_BUDGET_MIN_ROUND = 30
#: 候选序列最多几个模型。每个候选都是一次真实的上游会话，别配成整份目录。
DAILY_CHAT_MODELS_MAX = 8
#: 随机时段的基准小时区间，第二个时段 = 基准 + 12 小时（06–11 → 18–23）。
DAILY_CHAT_RANDOM_HOURS = (6, 11)
#: 随机时段的分钟区间。14220 全部落在整点批处理窗口（09:0x / 01:0x），
#: 分钟避开 00–04 就绕开了那一段。
DAILY_CHAT_RANDOM_MINUTES = (5, 55)
DAILY_CHAT_RANDOM_KEY = "daily_chat_random"
DAILY_CHAT_STARTUP_CATCHUP_KEY = "daily_chat_startup_catchup"
DAILY_CHAT_WEB_FALLBACK_ACTIVITY_KEY = "daily_chat_web_fallback_activity"


def _clean_models(value):
    """Normalize a candidate list: strings only, de-duplicated, order kept."""
    out = []
    for item in value or []:
        model = str(item or "").strip()
        if not model or model in out:
            continue
        out.append(model)
    return out[:DAILY_CHAT_MODELS_MAX]


def daily_chat_models(accounts_dir):
    """The ordered model candidates for the web activity; [] means "automatic".

    First entry is the preferred model, the rest are the fallback combination.
    An explicit list is used **in that order** - the old code kept the preferred
    model in one key and the fallback combination in another, then re-sorted the
    combination by catalogue multiplier, which is how a model picked in the
    panel ended up never running at all.
    """
    data = load(accounts_dir)
    stored = data.get("daily_chat_models")
    if isinstance(stored, (list, tuple)):
        return _clean_models(stored)
    # Upgrade path for installs that configured the old pair. The old fallback
    # list was only active when its switch was on; the preferred model still
    # ran first. Fold both into one ordered list so the panel starts from the
    # operator's actual prior behaviour instead of silently resetting.
    legacy_fallback = data.get("daily_chat_web_fallback") is True
    candidates = []
    preferred = str(data.get("daily_chat_model") or "").strip()
    if preferred:
        candidates.append(preferred)
    if legacy_fallback:
        raw = data.get("daily_chat_web_fallback_models")
        if isinstance(raw, str):
            raw = raw.replace("，", ",").split(",")
        elif isinstance(raw, (list, tuple)):
            raw = list(raw)
        else:
            raw = []
        candidates.extend(str(item or "").strip() for item in raw)
    if candidates:
        return _clean_models(candidates)
    return []


def set_daily_chat_models(accounts_dir, models):
    """Persist the ordered candidate list. Returns the stored list.

    An empty value clears the key, which means "automatic": the account's
    preferred model plus the realm's free models, ordered by multiplier.
    """
    cleaned = _clean_models(models)
    with _lock:
        data = load(accounts_dir)
        if cleaned:
            data["daily_chat_models"] = cleaned
        else:
            data.pop("daily_chat_models", None)
        save(accounts_dir, data)
    return cleaned


def daily_chat_budget(accounts_dir, default=None):
    """How long one account may spend on the web activity, in seconds.

    ``default`` is what an unset install gets, so a caller with its own
    built-in default keeps it. 0 disables the budget. This is the single knob
    that decides the worst case: rounds and the create-failure backoff both draw
    from it, so `ceil(accounts / concurrency) x budget` is the whole batch's
    upper bound.
    """
    if default is None:
        default = DAILY_CHAT_BUDGET_DEFAULT
    value = load(accounts_dir).get("daily_chat_budget")
    if isinstance(value, bool) or not isinstance(value, int) \
            or value < 0 or value > DAILY_CHAT_BUDGET_MAX:
        return default
    return value


def set_daily_chat_budget(accounts_dir, seconds):
    """Persist the per-account budget. Returns the stored whole number."""
    if isinstance(seconds, bool) or not isinstance(seconds, int):
        raise ValueError("daily_chat_budget must be a whole number")
    if seconds < 0:
        raise ValueError("daily_chat_budget cannot be negative")
    if seconds > DAILY_CHAT_BUDGET_MAX:
        raise ValueError("daily_chat_budget cannot be more than %d"
                         % DAILY_CHAT_BUDGET_MAX)
    with _lock:
        data = load(accounts_dir)
        data["daily_chat_budget"] = seconds
        save(accounts_dir, data)
    return seconds


def _draw_daily_chat_times():
    """Draw one base time and its +12h twin, minutes kept off the top of the hour."""
    hour = random.randint(*DAILY_CHAT_RANDOM_HOURS)
    minute = random.randint(*DAILY_CHAT_RANDOM_MINUTES)
    return ["%02d:%02d" % (hour, minute),
            "%02d:%02d" % ((hour + 12) % 24, minute)]


def daily_chat_random_times(accounts_dir, now=None):
    """Today's two random slots, 12 hours apart; drawn once per local day.

    Persisted because the scheduler re-reads settings every 30 seconds and the
    process may restart mid-day: re-drawing on each read would move the slots
    around under the accounts that already ran, and "next slot in ..." would
    never converge. The stored date is the guard.
    """
    moment = time.localtime(now) if now is not None else time.localtime()
    today = time.strftime("%Y-%m-%d", moment)
    data = load(accounts_dir)
    stored = data.get(DAILY_CHAT_RANDOM_KEY)
    if isinstance(stored, dict) and stored.get("date") == today:
        times = _normalize_times(stored.get("times"))
        if times and len(times) == 2:
            return times
    times = _draw_daily_chat_times()
    with _lock:
        data = load(accounts_dir)
        data[DAILY_CHAT_RANDOM_KEY] = {"date": today, "times": times}
        save(accounts_dir, data)
    return times


def daily_chat_effective_times(accounts_dir, now=None):
    """The slots the scheduler should actually use.

    An explicit `schedule.daily_chat` wins. When it is empty the activity runs
    on two random slots, 12 hours apart - the old "empty = follow the checkin
    hours" default put every run on 09:00 / 21:00, which is exactly the
    upstream batch window that answers 14220 (`failed to create initial
    session`).
    """
    explicit = daily_chat_times(accounts_dir)
    if explicit:
        return explicit
    return daily_chat_random_times(accounts_dir, now=now)


def daily_chat_startup_catchup(accounts_dir):
    """Whether a restart still catches up on today's missed activity.

    On unless the operator turns it off. A gateway that was down (or whose
    scheduler was stuck) during a slot used to wait for the next slot - up to
    12 hours - and if that one failed too, the day was simply lost.
    """
    value = load(accounts_dir).get(DAILY_CHAT_STARTUP_CATCHUP_KEY)
    return True if value is None else value is True


def set_daily_chat_startup_catchup(accounts_dir, enabled):
    """Persist the startup catch-up switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[DAILY_CHAT_STARTUP_CATCHUP_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def daily_chat_web_fallback_activity(accounts_dir):
    """Whether a web-channel TLS failure falls back to the activity report.

    Off unless the operator turns it on. The web channel is the only leg that
    actually earns the daily reward, so its failure is reported as a failure -
    otherwise the day looks done and the credits silently never arrive. The
    exception is a certificate failure on the sandbox endpoint (#645): that is
    an upstream/network configuration fault, retrying the same turn cannot
    fix it, and leaving the whole day failed while the streak can be lit by a
    plain POST /v2/report costs the operator the streak too. With this switch
    on, a TLS failure on the web leg reports activity instead of failing the
    round. Every other web failure keeps its old meaning.
    """
    return load(accounts_dir).get(DAILY_CHAT_WEB_FALLBACK_ACTIVITY_KEY) is True


def set_daily_chat_web_fallback_activity(accounts_dir, enabled):
    """Persist the web-leg fallback switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[DAILY_CHAT_WEB_FALLBACK_ACTIVITY_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def local_web_tools(accounts_dir):
    """Whether the gateway runs web_search / web_fetch calls itself.

    Off unless the operator turns it on. Forwarding the client's declaration
    untouched is what this gateway has done since v1.5.3, and it is what an
    install that never touched the switch keeps doing: the upstream has no
    server-side search tool, so a client declaring one runs it in its own
    process. Turning the switch on swaps the declaration for the gateway's own
    function and executes the calls locally (wb_webtools), which also means the
    gateway itself fetches the URLs a model asks for - hence opt-in only.
    """
    return load(accounts_dir).get("local_web_tools") is True


def set_local_web_tools(accounts_dir, enabled):
    """Persist the local web-tools switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["local_web_tools"] = enabled
        save(accounts_dir, data)
    return enabled


def accounts_collapsed(accounts_dir):
    """Whether the panel's account section is collapsed.

    Expanded unless the stored value is the boolean true. `is True` is the whole
    normalisation: a hand-edited "false", a 1, an object or a missing key all
    read as expanded, so none of them can hide the accounts by accident. The
    panel only ever writes a real boolean through set_accounts_collapsed.
    """
    return load(accounts_dir).get(ACCOUNTS_COLLAPSED_KEY) is True


def set_accounts_collapsed(accounts_dir, collapsed):
    """Persist the account-section disclosure state. Returns the stored boolean."""
    collapsed = bool(collapsed)
    with _lock:
        data = load(accounts_dir)
        data[ACCOUNTS_COLLAPSED_KEY] = collapsed
        save(accounts_dir, data)
    return collapsed


def key_before_hidden(accounts_dir):
    """Whether the per-API-key table folds away its `(切换前)` row.

    Shown unless the stored value is the boolean true, with the same `is True`
    normalisation as accounts_collapsed: the row is history worth seeing, so a
    hand-edited "false", a 1, an object or a missing key must all leave it
    visible rather than hide it by accident.
    """
    return load(accounts_dir).get(KEY_BEFORE_HIDDEN_KEY) is True


def set_key_before_hidden(accounts_dir, hidden):
    """Persist the `(切换前)` row disclosure state. Returns the stored boolean."""
    hidden = bool(hidden)
    with _lock:
        data = load(accounts_dir)
        data[KEY_BEFORE_HIDDEN_KEY] = hidden
        save(accounts_dir, data)
    return hidden


def _clean_page_keys(value):
    """Normalise a stored or patched page list into a clean list of keys.

    Anything that is not a list of well-formed keys is dropped rather than
    rejected, for the same reason the booleans above normalise instead of
    raising: the file is hand-editable, and the fail-safe direction for a
    display preference is "nothing hidden". Duplicates and over-long lists are
    collapsed so a hand edit cannot turn the panel's nav into a repeat of one
    entry.
    """
    if not isinstance(value, (list, tuple)):
        return []
    out = []
    for item in value:
        if not isinstance(item, str):
            continue
        key = item.strip()
        if not PAGE_KEY_RE.match(key) or key == PAGE_KEEP_VISIBLE or key in out:
            continue
        out.append(key)
        if len(out) >= MAX_HIDDEN_PAGES:
            break
    return out


def hidden_pages(accounts_dir):
    """The top-bar pages the panel hides. Empty on a fresh install.

    Normalised on every read, so a hand edit that puts a string, an unknown key
    or a duplicate in the file cannot hide a page twice or hide something the
    panel would then be unable to put back.
    """
    return _clean_page_keys(load(accounts_dir).get(HIDDEN_PAGES_KEY))


def set_hidden_pages(accounts_dir, pages):
    """Persist the hidden-page list. Returns the stored (normalised) list."""
    cleaned = _clean_page_keys(pages)
    with _lock:
        data = load(accounts_dir)
        data[HIDDEN_PAGES_KEY] = cleaned
        save(accounts_dir, data)
    return cleaned


def accounts_separate_tab(accounts_dir):
    """Whether the panel gives the account sections a main tab of their own.

    Off unless the stored value is the boolean true, with the same `is True`
    normalisation as the disclosures above: the merged "网关与账号" tab is what
    every install has always shown, so a hand-edited "false", a 1, an object or
    a missing key must all keep it rather than split the nav by accident.
    """
    return load(accounts_dir).get(ACCOUNTS_SEPARATE_TAB_KEY) is True


def set_accounts_separate_tab(accounts_dir, separate):
    """Persist the account-tab switch. Returns the stored boolean."""
    separate = bool(separate)
    with _lock:
        data = load(accounts_dir)
        data[ACCOUNTS_SEPARATE_TAB_KEY] = separate
        save(accounts_dir, data)
    return separate


def update_check_enabled(accounts_dir):
    """Whether the gateway checks for a newer release once a day.

    Off unless the operator turns it on, and off for an install that predates
    the key: this is the one setting here whose missing value means "no", since
    enabling it makes the gateway talk to GitHub on its own schedule. The manual
    check in the panel ignores this switch entirely.
    """
    return load(accounts_dir).get(UPDATE_CHECK_ENABLED_KEY) is True


def set_update_check_enabled(accounts_dir, enabled):
    """Persist the daily-check switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data[UPDATE_CHECK_ENABLED_KEY] = enabled
        save(accounts_dir, data)
    return enabled


def update_check_proxy_slot(accounts_dir):
    """Proxy slot used only by the release checker; "" means direct."""
    value = load(accounts_dir).get(UPDATE_CHECK_PROXY_SLOT_KEY)
    return str(value or "").strip()[:64]


def set_update_check_proxy_slot(accounts_dir, slot_id):
    """Persist the optional update-check proxy slot. Returns the stored id."""
    slot_id = str(slot_id or "").strip()[:64]
    with _lock:
        data = load(accounts_dir)
        if slot_id:
            data[UPDATE_CHECK_PROXY_SLOT_KEY] = slot_id
        else:
            data.pop(UPDATE_CHECK_PROXY_SLOT_KEY, None)
        save(accounts_dir, data)
    return slot_id


def window_probe(accounts_dir):
    """是否在模型额度窗口重置时刻主动发探针请求，抢占新一轮计时。

    上游的免费额度窗口按「首次请求」起算，打满后 429 会给出 `reset at`。
    到点若无人请求，新一轮窗口就不会开始，额度一直空转。默认开启：这是
    本网关把窗口起点钉在重置那一刻的唯一手段。关掉它的部署回到旧行为——
    429 只记冷却，等真实请求自己撞上重置点。
    """
    value = load(accounts_dir).get("window_probe")
    return True if value is None else value is True


def set_window_probe(accounts_dir, enabled):
    """Persist the window-probe switch. Returns the stored boolean."""
    enabled = bool(enabled)
    with _lock:
        data = load(accounts_dir)
        data["window_probe"] = enabled
        save(accounts_dir, data)
    return enabled


def update_check_state(accounts_dir):
    """The last-check bookkeeping: when it ran, and the version it saw.

    Three fields plus one bounded list. The 24h cadence needs `last_attempt` to
    survive a restart, and `latest_version` is what lets the panel answer right
    after one; `startup_checks` holds the timestamps of the last few
    startup-time checks so the budget in wb_updates can be counted across
    restarts. Everything else about a check lives in memory, and nothing from
    the HTTP exchange - URL, headers, body - is ever stored here.
    """
    stored = load(accounts_dir).get(UPDATE_CHECK_STATE_KEY)
    stored = stored if isinstance(stored, dict) else {}
    out = {"last_attempt": 0.0, "last_success": 0.0, "latest_version": "",
           "startup_checks": []}
    for key in ("last_attempt", "last_success"):
        value = stored.get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value > 0:
            out[key] = float(value)
    version = stored.get("latest_version")
    if isinstance(version, str):
        out["latest_version"] = version.strip()[:32]
    stamps = stored.get("startup_checks")
    if isinstance(stamps, list):
        kept = [float(item) for item in stamps
                if isinstance(item, (int, float)) and not isinstance(item, bool)
                and item > 0]
        out["startup_checks"] = sorted(kept)[-STARTUP_CHECK_STAMPS_KEPT:]
    return out


def record_startup_check(accounts_dir, at=None):
    """Append one startup-time check to the budget ledger. Returns the state.

    A separate write path from record_update_check() on purpose: that one keeps
    "last attempt / last success / version seen", while the budget needs "when
    did the last few startup passes happen". Folding the two together would make
    `last_attempt` mean two different things and leave the cadence unreadable.
    """
    stamp = float(at if at is not None else time.time())
    with _lock:
        data = load(accounts_dir)
        state = data.get(UPDATE_CHECK_STATE_KEY)
        state = dict(state) if isinstance(state, dict) else {}
        stamps = state.get("startup_checks")
        kept = [float(item) for item in stamps
                if isinstance(item, (int, float)) and not isinstance(item, bool)
                and item > 0] if isinstance(stamps, list) else []
        kept.append(stamp)
        state["startup_checks"] = sorted(kept)[-STARTUP_CHECK_STAMPS_KEPT:]
        data[UPDATE_CHECK_STATE_KEY] = state
        save(accounts_dir, data)
    return update_check_state(accounts_dir)


def record_update_check(accounts_dir, at=None, success=False, latest_version=""):
    """Write one check's outcome. Returns the stored state.

    One narrow write path on purpose: a checker that could write arbitrary keys
    into settings.json would turn it into an update-state database, which is
    what this is meant not to become.
    """
    stamp = float(at if at is not None else time.time())
    with _lock:
        data = load(accounts_dir)
        state = data.get(UPDATE_CHECK_STATE_KEY)
        state = dict(state) if isinstance(state, dict) else {}
        state["last_attempt"] = stamp
        if success:
            state["last_success"] = stamp
        version = str(latest_version or "").strip()[:32]
        if version:
            state["latest_version"] = version
        data[UPDATE_CHECK_STATE_KEY] = state
        save(accounts_dir, data)
    return update_check_state(accounts_dir)


def _clean_quota_scan_models(value):
    """Normalize the watch list into model ids in the order given.

    Ids are kept verbatim (they are sent upstream as `model`), only trimmed and
    de-duplicated; a hand-edited settings.json usually holds a comma-separated
    string, so both shapes are accepted.
    """
    if isinstance(value, str):
        raw = re.split(r"[,;\n]", value)
    elif isinstance(value, (list, tuple, set)):
        raw = list(value)
    else:
        return []
    out = []
    for item in raw:
        name = str(item or "").strip()
        if name and name not in out:
            out.append(name)
    return out


def quota_scan_models(accounts_dir):
    """Model ids the operator asked to watch, whether throttled or not.

    The window probe only knows about a quota line once something hit its 429;
    this list is how a line can be checked *before* it is exhausted, so hitting
    the limit is discovered on an idle timer instead of mid-request. Empty means
    the feature is off, which is what an install that predates the setting reads
    back as.
    """
    return _clean_quota_scan_models(load(accounts_dir).get("quota_scan_models"))


def set_quota_scan_models(accounts_dir, models):
    """Replace the watch list. Returns the stored list."""
    cleaned = _clean_quota_scan_models(models)
    with _lock:
        data = load(accounts_dir)
        data["quota_scan_models"] = cleaned
        save(accounts_dir, data)
    return cleaned


_SLOT_ID_RE = re.compile(r"^slot-(\d+)$")


def normalize_proxy_url(url):
    """Normalize user/vendor proxy input into standard http://[user:pass@]host:port.

    Supports:
      - host:port:user:pass or http://host:port:user:pass (vendor format)
      - user:pass@host:port (adds missing http:// scheme)
      - standard http://user:pass@host:port or http://host:port
    """
    raw = str(url or "").strip()
    if not raw:
        return ""
    scheme = "http"
    if "://" in raw:
        s, _, rest = raw.partition("://")
        scheme = s.strip().lower() or "http"
        raw = rest.strip()
    parts = raw.split(":")
    if len(parts) == 4 and parts[1].isdigit():
        host, port, user, password = parts[0], parts[1], parts[2], parts[3]
        return "%s://%s:%s@%s:%s" % (scheme, user, password, host, port)
    return "%s://%s" % (scheme, raw)


def _clean_slot_entry(entry, fallback_id=None):
    """Normalize one stored slot; returns None when unusable.

    The exit fields are written by a probe and stay empty until one runs. An
    empty name means "label this slot by its exit", which is what the panel
    shows; it is never silently replaced by the id here, or the operator could
    not tell an auto-named slot from a renamed one.
    """
    if not isinstance(entry, dict):
        return None
    url = normalize_proxy_url(entry.get("url"))
    if not url:
        return None
    slot_id = str(entry.get("id") or "").strip()
    if not slot_id:
        slot_id = fallback_id or ""
    try:
        probed_at = int(entry.get("probed_at") or 0)
    except (TypeError, ValueError):
        probed_at = 0
    return {
        "id": slot_id,
        "name": str(entry.get("name") or "").strip(),
        "url": url,
        "enabled": entry.get("enabled", True) is not False,
        "ip": str(entry.get("ip") or "").strip(),
        "country": str(entry.get("country") or "").strip(),
        "country_code": str(entry.get("country_code") or "").strip().upper(),
        "ip_type": str(entry.get("ip_type") or "").strip().lower(),
        "isp": str(entry.get("isp") or "").strip(),
        "asn": str(entry.get("asn") or "").strip(),
        "probed_at": probed_at,
    }


def _next_slot_id(existing):
    """Next unused `slot-<n>` id for a legacy list stored without ids."""
    highest = 0
    for entry in existing:
        match = _SLOT_ID_RE.match(str(entry.get("id") or ""))
        if match:
            highest = max(highest, int(match.group(1)))
    return "slot-%d" % (highest + 1)


def _slot_seq(data):
    """Highest slot number ever issued in this store."""
    try:
        return int(data.get("proxy_slot_seq") or 0)
    except Exception:
        return 0


def proxy_slots(accounts_dir):
    """Every configured proxy slot, in stored order."""
    data = load(accounts_dir)
    stored = data.get("proxy_slots")
    if not isinstance(stored, list):
        return []
    out, seen = [], set()
    for raw in stored:
        entry = _clean_slot_entry(raw)
        if entry and entry["url"] not in seen:
            seen.add(entry["url"])
            if not entry["id"]:
                entry["id"] = _next_slot_id(out)
            out.append(entry)
    return out


def set_proxy_slots(accounts_dir, slots):
    """Replace the whole slot list. Returns the stored list.

    Ids are drawn from a counter that only ever grows. Accounts persist the
    id they are bound to, so recycling a freed id would silently re-point an
    existing account at a newly added slot's exit IP.
    """
    with _lock:
        data = load(accounts_dir)
        stored = data.get("proxy_slots")
        stored = stored if isinstance(stored, list) else []

        seq = _slot_seq(data)
        # Seed from both the incoming and the outgoing list, so an id that is
        # being removed in this very save can never be handed to a new entry.
        for entry in list(stored) + list(slots or []):
            if not isinstance(entry, dict):
                continue
            match = _SLOT_ID_RE.match(str(entry.get("id") or ""))
            if match:
                seq = max(seq, int(match.group(1)))
        # A legacy list stored without ids is displayed as slot-1..slot-N, so
        # keep the counter above those too.
        seq = max(seq, len(stored))

        cleaned, seen = [], set()
        for raw in slots or []:
            entry = _clean_slot_entry(raw)
            if not entry or entry["url"] in seen:
                continue
            seen.add(entry["url"])
            if not entry["id"] or any(e["id"] == entry["id"] for e in cleaned):
                seq += 1
                entry["id"] = "slot-%d" % seq
            cleaned.append(entry)
        data["proxy_slots"] = cleaned
        data["proxy_slot_seq"] = seq
        save(accounts_dir, data)
        return cleaned


def update_proxy_slot(accounts_dir, slot_id, fields, defaults=None):
    """Merge `fields` into one stored slot; returns the merged copy, or None.

    Both the read and the write happen under the store lock. A plain
    read-modify-write from the caller would race with a panel save and write
    back a list that no longer matches what is on disk, silently reverting
    whatever the other writer changed.

    `defaults` are applied only to fields that are still empty at write time,
    so a value the operator typed while the caller was working is never
    overwritten by a derived one.
    """
    slot_id = str(slot_id or "").strip()
    if not slot_id:
        return None
    with _lock:
        out, found = [], None
        for entry in proxy_slots(accounts_dir):
            if entry["id"] == slot_id and found is None:
                entry = dict(entry)
                entry.update(fields)
                for key, value in (defaults or {}).items():
                    if not entry.get(key):
                        entry[key] = value
                found = entry
            out.append(entry)
        if found is None:
            return None
        data = load(accounts_dir)
        data["proxy_slots"] = out
        save(accounts_dir, data)
        return found


def drop_missing_bindings(pool, slots):
    """Clear bindings that point at a slot which no longer exists.

    Without this the stale id stays on the account, and a later slot that
    happens to receive that id would capture the account.
    """
    valid = {entry["id"] for entry in slots}
    changed = 0
    for account in list(getattr(pool, "accounts", []) or []):
        if account.proxy_slot and account.proxy_slot not in valid:
            account.proxy_slot = ""
            try:
                account.save(pool.dir)
            except Exception:
                pass
            changed += 1
    if changed:
        pool.apply_proxy_slots(slots)
    return changed


def find_proxy_slot(accounts_dir, slot_id):
    slot_id = str(slot_id or "").strip()
    if not slot_id:
        return None
    for entry in proxy_slots(accounts_dir):
        if entry["id"] == slot_id:
            return entry
    return None


class PanelSessions(object):
    """In-memory bearer tokens handed out after a successful panel login.

    Deliberately not persisted: restarting the gateway logs browsers out, which
    is the safer default for a LAN tool that people expose behind a port map.
    """

    def __init__(self, ttl=SESSION_TTL):
        self.ttl = ttl
        self._tokens = {}
        self._lock = threading.RLock()

    def create(self):
        token = secrets.token_urlsafe(24)
        with self._lock:
            self._tokens[token] = time.time() + self.ttl
        return token

    def valid(self, token):
        if not token:
            return False
        with self._lock:
            expiry = self._tokens.get(token)
            if not expiry:
                return False
            if expiry < time.time():
                self._tokens.pop(token, None)
                return False
            return True

    def revoke(self, token):
        if not token:
            return
        with self._lock:
            self._tokens.pop(token, None)

    def revoke_all(self):
        with self._lock:
            self._tokens.clear()
